const VERSION_URL = "https://raw.githubusercontent.com/contentWizardWL/autoupdate/main/version.json?v=" + Math.random();
const CURRENT_VERSION = chrome.runtime.getManifest().version;
document.querySelector('h1').textContent = `Content Wizard v${CURRENT_VERSION}`;

const API_PROMO = 'https://script.google.com/a/macros/redcore.group/s/AKfycbxGlkR0X_u--hvQwHVr3oSIiaRSrCGS1pqqNN1F5ez2_gzqqM9ca8LE17suQ2EkcKJGjQ/exec';
const API_ADVENT = 'https://script.google.com/a/macros/redcore.group/s/AKfycbw8XEHvEmFZOJ3_Q5PFP_9KqqjZFta9goqD2fBGV-DXAbnz66VlswCfWVAMhTUWqJH6oQ/exec';
const API_RULES = 'https://script.google.com/a/macros/redcore.group/s/AKfycbyu4Ic8njHt0qAU2iyAyQwpAEuVtjr-XObJftn6vc6sHwhQCGyeCAdGpO6frQQMxYpK7A/exec';
const API_TOURNAMENT = 'https://script.google.com/a/macros/redcore.group/s/AKfycbw4N8-yTX_XAZXrNW1tZ3awD-Hdnta3tsEHHnx4AfyyPwTRrzES3jX_0MrNiazCrtKA2A/exec';
const API_PRETTY = 'https://script.google.com/a/macros/redcore.group/s/AKfycbwgtUwoLBhLCrhJoeJ-j8tcereJkcTzjppxZNP6Ntx6FJxOFS6qf8OQul54IO5iPMUT/exec';

const CURRENCIES = ["EUR", "USD", "RUB", "TRY", "KZT", "AZN", "UZS", "CAD", "KGS", "TJS"];
const LANGUAGES = ["RU", "KZ", "AZ", "TR", "EN", "FR", "KG", "TJ", "UZ", "MG"];
const ACTIVITY_TYPE = ['Casino', 'Sport', 'SMM', 'Tournaments'];

const DOC_MODE = {
  show: ['docUrl'],
  placeholder: "https://docs.google.com/document/...",
};

const UI_MAP = {
  promo: DOC_MODE,
  advent: DOC_MODE,
  tournament: DOC_MODE,
  locales: {
    show: ['docUrl'],
    placeholder: ['AZ, TR, KZ...'],
  },
  segments: {
    show: ['docUrl', 'segmentsType'],
    placeholder: ['3405 UP_UP_popup_QAMAR_WL'],
  },
  link: {
    show: ['docUrl', 'selectFieldsWrap'],
    placeholder: "slot (/casino/...)",
  },
  hidden: {
    show: ['detailsOptions'],
  },
  variables: {
    show: ['docUrl'],
    placeholder: "20 USD / 1 800 RUB / 1 000 TRY...",
  },
  rules: {
    show: ['rulesSCOption'],
  },
  steps : {
    show: ['stepsCount'],
  },
  pretty: {
    show: ['prettyOp'],
  },
};

const LANG_COL = Object.freeze({ RU: "B", EN: "C", KZ: "D", TR: "E", AZ: "F", KG: "G", UZ: "H", FR: "I", TJ: "J", MG: "K"});

function generateRuleMap(ranges) {
  const map = {};
  for (const { start, end, startIndex } of ranges) {
    let index = startIndex;
    if (start.startsWith('Hidden')) {
      if (end) {
        const startNum = Number(start.split(' ')[1] || 1);
        const endNum = Number(end.split(' ')[1] || startNum);
        for (let i = startNum; i <= endNum; i++) {
          map[`Hidden ${i}`] = index++;
        }
      } else {
        map['Hidden'] = index++;
      }
      continue;
    }
    const [startMajor, startMinor] = start.split('.').map(Number);
    const [endMajor, endMinor] = end?.split('.')?.map(Number) || [startMajor, startMinor];

    for (let major = startMajor; major <= endMajor; major++) {
      const minorStart = major === startMajor ? startMinor : 1;
      const minorEnd = major === endMajor ? endMinor : 99;
      for (let minor = minorStart; minor <= minorEnd; minor++) {
        map[`${major}.${minor}`] = index++;
        if (major === endMajor && minor === endMinor) break;
      }
    }
  }
  return Object.freeze(map);
}

const CAS_RULE_ROWS_MAP = generateRuleMap([
  {start: '1.1', end: '1.11', startIndex: 4},
  {start: '2.1', end: '2.25', startIndex: 17},
  {start: '3.1', startIndex: 43},
  {start: '4.1', end: '4.2', startIndex: 48},
  {start: 'Hidden', startIndex: 52},
])
const SP_RULE_ROWS_MAP = generateRuleMap([
  { start: '1.1', end: '1.9', startIndex: 3 },
  { start: '2.1', end: '2.18', startIndex: 14 },
  { start: 'Hidden 1', end: 'Hidden 7', startIndex: 33 },
]);
const SMM_RULE_ROWS_MAP = generateRuleMap([
  { start: '1.1', end: '1.9', startIndex: 3 },
  { start: '2.1', startIndex: 12 },
  { start: 'Hidden 1', end: 'Hidden 4', startIndex: 14 },
])
const TOURNAMENTS_RULE_ROWS_MAP = Object.freeze({ "Regular": 1 });

const RULE_ROWS_MAP = Object.freeze({
  Casino: CAS_RULE_ROWS_MAP,
  Sport: SP_RULE_ROWS_MAP,
  SMM: SMM_RULE_ROWS_MAP,
  Tournaments: TOURNAMENTS_RULE_ROWS_MAP,
});

let RULE_ROWS = {};

const chooseFields = document.getElementById("chooseFields");
const currencyOptions = document.getElementById("currencyOptions");
const languageOptions = document.getElementById("languageOptions");
const rulesActivityOption = document.getElementById("rulesSCOption");
const rulesLang = document.getElementById("rulesLang");
const stepsCount = document.getElementById("stepsCount");
const segmentsType = document.getElementById("segmentsType");
const detailsOptions = document.getElementById("detailsOptions");
const pretty = document.getElementById('prettyOp');

function createOptionButtons(container, items, options = {}, sp = '_') {
  const { type = "checkbox", name = "", className = "" } = options;
  // options: { type: "checkbox" | "radio", name?: string, className?: string }
  items.forEach(item => {
    const input = document.createElement("input");
    input.type = type;
    if (type === "radio") input.name = name;
    input.id = `${type}${sp}${item}`;
    input.value = item;
    input.style.display = "none";

    const label = document.createElement("label");
    label.htmlFor = input.id;
    label.className = `toggle-btn ${className}`.trim();
    label.textContent = item;

    container.appendChild(input);
    container.appendChild(label);
  });
}

function createRuleButtons() {
  const container = document.getElementById('rulesNumbers');
  container.innerHTML = '';
  let currentGroup = null;
  let groupDiv = null;
  let group = 0;
  Object.keys(RULE_ROWS).forEach(rule => {
    if (rule.includes(".")) group = rule.split(".")[0];
    else group = 'hidden';

    if (group !== currentGroup) {
      currentGroup = group;

      groupDiv = document.createElement("div");
      groupDiv.className = "rules-group-active";
      container.appendChild(groupDiv);
    }
    const input = document.createElement('input');
    input.type = 'radio';
    input.name = 'ruleNumber';
    input.value = rule;
    input.id = `rule_${rule}`;

    const label = document.createElement('label');
    label.htmlFor = input.id;
    label.textContent = rule;
    label.className = 'toggle-btn currency';

    groupDiv.appendChild(input);
    groupDiv.appendChild(label);
  });
}

const OPTION_BUTTONS = [
  [currencyOptions, CURRENCIES, { type: "checkbox", className: "currency" }],
  [languageOptions, LANGUAGES, { type: "radio", name: "languages", className: "currency" }],
  [rulesActivityOption, ACTIVITY_TYPE, { type: "radio", name: "activity", className: "currency" }],
  [rulesLang, LANGUAGES, { type: "radio", name: "rulesLang", className: "currency" }, '-'],
  [stepsCount, ['3','4','5'], { type: "radio", name: "stepsCount", className: "currency" }],
  [segmentsType, ['Included', 'Excluded', 'Excluded Casino', 'Excluded Sport'], {type: "radio", name: "segmentsType", className: "currency"}],
  [detailsOptions, ['Add', 'Remove'], { type: "radio", name: "detailsOptions", className: "currency" }],
  [pretty, ['Casino Template', 'Sport Template',], { type: "radio", name: "pretty", className: "currency" }]
];

OPTION_BUTTONS.forEach(args => createOptionButtons(...args));

function updateUI() {
  const type = document.querySelector('input[name="type"]:checked')?.value;
  const config = UI_MAP[type] || {};

  const textField = document.getElementById('docUrl');
  textField.style.display = 'none';
  
  document.querySelectorAll('.option-group').forEach(el => {
    el.style.display = 'none';
  });

  document.querySelectorAll('.option-group input').forEach(input => {
    input.checked = false;
  });

  const selectFieldsWrap = document.getElementById('selectFieldsWrap');

  chooseFields.checked = false;
  selectFieldsWrap.style.display = 'none';
  currencyOptions.style.display = 'none';

  (config.show || []).forEach(id => {
    const el = document.getElementById(id);
    if (el) el.style.display = "flex";
  });

  if (config.placeholder) {
    const docInput = document.getElementById('docUrl');
    docInput.placeholder = config.placeholder;
    docInput.value = '';
  }
}

document.addEventListener("change", (e) => {
  const target = e.target;
  // === escludedSegments ===
  if (target.closest("#segmentsType") && target.matches('input[type="radio"]')) {
    document.getElementById("docUrl").style.display = (target.value === 'Excluded Casino' || target.value === 'Excluded Sport') ? "none" : "flex";
  };

  // === detailsOptions ===
  if (target.closest("#detailsOptions") && target.matches('input[type="radio"]')) {
    document.getElementById("languageOptions").style.display = target.value === 'Add' ? "flex" : "none";
  };

  // === rulesActivityOption ===
  if (target.closest("#rulesSCOption") && target.matches('input[type="radio"]')) {
    RULE_ROWS = RULE_ROWS_MAP[target.value];
    createRuleButtons();
    rulesLang.style.display = "flex";
  };

  // === rulesLang ===  
  if (target.closest("#rulesLang") && target.matches('input[type="radio"]')) {
    document.getElementById("rulesNumbers").style.display = "flex";
    document.querySelectorAll('.rules-group-active').forEach(el => {
      el.style.display = "flex";
      el.style.flexWrap = "wrap";
    });
  };

  // === chooseFields ===
  if (target.id === "chooseFields") {
    currencyOptions.style.display = target.checked ? "flex" : "none";
  };

  // === updateUI for type radios ===
  if (target.matches('input[name="type"]')) {
    updateUI();
  };
});

function sendToActiveTab(messageType, payload) {
  chrome.tabs.query({ active: true, currentWindow: true }, ([tab]) => {
    if (!tab) return;

    chrome.tabs.sendMessage(tab.id, {
      type: messageType,
      payload
    });
  });
}

document.getElementById('load').addEventListener('click', async () => {
  const inputValue = document.getElementById('docUrl').value.trim();

  const type = document.querySelector('input[name="type"]:checked').value;

  if (type === 'link') {
    let selectedCurrencies = [];
    if (chooseFields.checked) {
      selectedCurrencies = [
        ...currencyOptions.querySelectorAll('input[type="checkbox"]:checked')
      ].map(input => input.value);
    }
    sendToActiveTab('FILL_LINK', { url: inputValue, currencies: selectedCurrencies, });
    return;
  }

  if (type === 'variables') {
    sendToActiveTab('FILL_VARIABLES', inputValue);
    return;
  }

  if (type === 'steps') {
    const stepNumber = document.querySelector('#stepsCount input[type="radio"]:checked')?.value;
    sendToActiveTab('FILL_STEPS', stepNumber);
    return;
  }

  if (type === 'segments') {
    const segment = document.querySelector('#segmentsType input[type="radio"]:checked')?.value;
    sendToActiveTab('FILL_SEGMENTS', { segments: inputValue, type: segment, });
    return;
  }

  if (type === 'locales') {
    sendToActiveTab('FILL_LOCALES', inputValue);
    return;
  }

  if (type === 'hidden') {
  const selectedOption = document.querySelector('#detailsOptions input[type="radio"]:checked').value
  const selectedLanguage = selectedOption === 'Add' ? document.querySelector('#languageOptions input[type="radio"]:checked').value : '';
  
  chrome.tabs.query({ active: true, currentWindow: true }, ([tab]) => {

    chrome.scripting.executeScript({
      target: { tabId: tab.id },
      world: "MAIN",
      func: (language, option) => {
        const HIDDEN_PART = {
          RU: "Правила и условия",
          EN: "Terms and conditions",
          AZ: "Qaydalar və şərtlər",
          FR: "Règles et conditions",
          KZ: "Ережелер мен шарттар",
          KG: "Эрежелер жана шарттар",
          TJ: "Қоидаҳо ва шартҳо",
          TR: "Kurallar ve koşullar",
          UZ: "Qoidalar va shartlar",
          MG: "Дүрэм ба нөхцөлүүд",
        }
        const editor = window.tinymce?.activeEditor;

        editor.focus();
        editor.undoManager.transact(() => {
          const content = editor.getContent();
          if (option === 'Add') {
            const parts = content.split('<p>&nbsp;</p>');
            const before = parts[0] || '';
            const after = parts[1] || '';
            editor.setContent(before + `<details><summary>${HIDDEN_PART[language]}</summary>` + after + `</details>`);
          } else {
            const parts = content.split('<details>');
            const before = parts[0] || '';
            const after = parts[1].replace(/<summary>[\s\S]*?<\/summary>/gi, '<p>&nbsp;</p>').replace(/<\/details>\s*$/i, '') || '';
            editor.setContent(before + after);
          }
        });
      },
      args: [selectedLanguage, selectedOption]
    });
  });
  return;
  }
  
  if (type === 'rules') {   
    const activity = document.querySelector('input[name="activity"]:checked')?.value;
    const selectedRule = document.querySelector('input[name="ruleNumber"]:checked')?.value;
    const selectedLang = document.querySelector('input[name="rulesLang"]:checked')?.value;
    const column = LANG_COL[selectedLang];
    const row = RULE_ROWS[selectedRule];
    const cell = `${column}${row}`;

    let data;
    try {
      const res = await fetch(`${API_RULES}?activity=${encodeURIComponent(activity)}&cell=${encodeURIComponent(cell)}`);
      data = await res.json();
    } catch (err) {
      console.error(err);
      return;
    }

    chrome.tabs.query({ active: true, currentWindow: true }, ([tab]) => {
      if (!tab) return;

      chrome.scripting.executeScript({
        target: { tabId: tab.id },
        world: "MAIN",
        args: [data],
        func: (rulesData) => {
          const editor = window.tinymce?.activeEditor;
          if (!editor) return;

          let text = '';
          
          for (let i = 0; i < rulesData.length; i++) {
            text += rulesData[i];
          }
          if (text === "<ol></ol>" || !text) text = 'Не верный формат правил.'
          editor.focus();
          const currentContent = editor.getContent();
          editor.setContent(currentContent + text);
        }
      });
    });
  }

  function getActiveTabUrl() {
    return new Promise((resolve) => {
      chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
        resolve(tabs[0]?.url || '');
      });
    });
  }

  const CONFIG = {
    promo: { 
      api: () => `${API_PROMO}?url=${encodeURIComponent(inputValue)}`, 
      message: 'FILL_PROMO' 
    },
    advent: { 
      api: () => `${API_ADVENT}?url=${encodeURIComponent(inputValue)}`, 
      message: 'FILL_ADVENT' 
    },
    tournament : { 
      api: () => `${API_TOURNAMENT}?url=${encodeURIComponent(inputValue)}`, 
      message: 'FILL_TOURNAMENT' 
    },
    pretty: { 
      api: () => getActiveTabUrl().then(url => {
        const prettyType = document.querySelector('#prettyOp input[type="radio"]:checked')?.value === 'Casino Template' ? 'casino' : 'sport';
        return `${API_PRETTY}?url=${encodeURIComponent(url)}&type=${encodeURIComponent(prettyType)}`;
      }),
      message: 'SHOW_ALERT'
    }
  };

  const cfg = CONFIG[type];
  try {
    let res;
    const apiUrl = await cfg.api();
    if (apiUrl) res = await fetch(apiUrl);
    else res = await fetch(cfg.api());
    
    if (cfg.message) {
      const data = await res.json();
      if (data.error) {
        console.error(data.error);
        return;
      }

      let payload = data;
      if (type === 'pretty') {
        payload = {
          ...data,
          colors: {
            bg: getComputedStyle(document.documentElement).getPropertyValue('--main-btn').trim(),
            txt: getComputedStyle(document.documentElement).getPropertyValue('--btn-txt').trim()
          }
        };
      }

      chrome.tabs.query({ active: true, currentWindow: true }, async ([tab]) => {
        if (!tab) return;
        chrome.tabs.sendMessage(tab.id, { type: cfg.message, payload });
      });
    }
  } catch (err) {
    console.error(err);
  }
});

// === Update Check ====

initUpdateCheck();

async function initUpdateCheck() {
  try {
    const r = await fetch(VERSION_URL, { cache: "no-store" });
    if (!r.ok) return;
    const data = await r.json();
    const latest = data.version;
    const download = data.download;
    const updates = data.updates.map(u => `<span>${u}</span>`).join('<br>');
    if (!latest) return;

    const box = document.getElementById("updateBox");

    if (latest !== CURRENT_VERSION) {
      box.style.display = "block";
      box.innerHTML = `
        <div style="
          display: flex;
          flex-direction: column;
          justify-content: center;
          background: var(--body-bg);
          color: var(--p-txt);
          padding: 8px 12px;
          border-radius: 6px;
          font-size: 12px;
          border: 1px solid var(--brd);
          width: 100%;
          box-sizing: border-box;">

          <span style="display: block; text-align: center;">Better than before. Version ${latest} is here</span>
          <br>
          ${updates}
          
          <button id="downloadUpdate" class="toggle-btn" style="
            background: var(--input-field);
            color: var(--input-txt);
            border-radius: 6px;
            padding: 4px 8px;
            cursor: pointer;
            border: 1px solid var(--brd);
            font-size: 12px;
            white-space: nowrap;
            flex: 0 0 auto;
            width: auto;
            align-self: center;">Get it now</button>
        </div>
      `;

      document.getElementById("downloadUpdate").onclick = () => {
        chrome.tabs.create({ url: download });
      };
      return;
    }

    box.style.display = "none";
    box.innerHTML = '';
    checkReloadNeeded(box);

  } catch (e) {
    console.log("update check fail", e);
  }
}

// === Reload Check ===
function checkReloadNeeded(box) {
  chrome.tabs.query({ active: true, currentWindow: true }, ([tab]) => {
    chrome.tabs.sendMessage(tab.id, { type: "PING_EXTENSION" }, (res) => {
      if (chrome.runtime.lastError || !res) {
        box.style.display = "block";
        box.innerHTML = `
          <div style="
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            gap: 6px;
            background: var(--input-field);
            color: var(#e5e7eb);
            padding: 8px 12px;
            border-radius: 6px;
            font-size: 12px;
            border: 1px solid var(--brd);
            width: 100%;
            box-sizing: border-box;
          ">
            <span style="
              opacity: 0;
              animation: fadeBlink 3.5s ease-in-out infinite;
            ">
              It’s not broken. Just refresh the page.
            </span>
          </div>

          <style>
            @keyframes fadeBlink {
              0%   { opacity: 0.3; }
              50%  { opacity: 1; }
              100% { opacity: 0.3; }
            }
          </style>
        `;
      }
    });
  });
}

// === Theme ===
const themeCurrent = document.getElementById('themeCurrent');
const themeDropdown = document.getElementById('themeDropdown');

themeCurrent.addEventListener('click', () => {
  themeDropdown.style.display =
    themeDropdown.style.display === 'block' ? 'none' : 'block';
});

function applyTheme(theme) {
  const root = document.documentElement;

  for (const sheet of document.styleSheets) {
    for (const rule of sheet.cssRules) {
      if (!rule.selectorText) continue;
      if (rule.selectorText === `[data-theme="${theme}"]`) {
        const cssText = rule.style.cssText;
        cssText.split(';').forEach(decl => {
          if (!decl) return;
          const [prop, value] = decl.split(':').map(s => s.trim());
          if (!prop || !value) return;
          const baseName = prop.slice(0, prop.lastIndexOf(`-${theme}`));
          root.style.setProperty(baseName, value);
        });
      }
    }
  }
}

document.querySelectorAll('.theme-option').forEach(opt => {
  opt.addEventListener('click', () => {
    const theme = opt.dataset.theme;
    applyTheme(theme);
    localStorage.setItem('cw_theme', theme);

    themeCurrent.textContent = opt.textContent + ' ▽';
    themeDropdown.style.display = 'none';
  });
});

(function initTheme() {
  let saved = localStorage.getItem('cw_theme');

  if (!saved || !document.querySelector(`[data-theme="${saved}"]`)) {
    saved = 'dark-blue';
  }

  applyTheme(saved);

  const active = document.querySelector(`.theme-option[data-theme="${saved}"]`);
  if (active) {
    themeCurrent.textContent = active.textContent + ' ▽';
  }
})();