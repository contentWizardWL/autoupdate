const CURRENCIES_MAP = {
  USD: "$",
  EUR: "€",
  TRY: "₺",
  RUB: "₽",
  KZT: "₸",
  AZN: "₼",
  KGS: "⊆",
  UZS: "SO'M",
  CAD: "C$",
  TJS: "SM"
};

const CURRENCIES = ["EUR", "USD", "RUB", "TRY", "KZT", "AZN", "UZS", "CAD", "KGS", "TJS"];

const PREFIX_CURRENCIES = ["USD", "EUR", "TRY", "CAD"];

function tinyMceFiller (data, indx = 0) {
  const iframe = document.querySelectorAll('.tox-edit-area__iframe');
  const doc = iframe[indx].contentDocument || iframe[indx].contentWindow?.document;
  const text = (data || []).join('');
  doc.body.innerHTML = text;
  doc.body.dispatchEvent(new Event('input', { bubbles: true }));
}

const fillFirstEmptyInput = (selector, value) => {
  const inputs = Array.from(document.querySelectorAll(selector));
  const emptyInput = inputs.find(input => !input.value.trim());
  if (emptyInput) {
    emptyInput.value = value || '';
    emptyInput.dispatchEvent(new Event('input', { bubbles: true }));
  }
};

async function fillTableRows({
  tableIndex,
  data,
  selector,
  delayAfterFill = 100
}) {
  const tables = document.querySelectorAll('table');
  const tbody = tables[tableIndex]?.querySelector('tbody');
  if (!tbody) return;

  const trs = [...tbody.querySelectorAll('tr')];

  for (let i = 0; i < data.length; i++) {
    const tr = trs[i * 2];
    if (!tr) continue;

    tr.click();

    const input = await waitForEmptyInput(selector);

    if (input) {
      input.value = data[i];
      input.dispatchEvent(new Event('input', { bubbles: true }));
      await sleep(delayAfterFill);
    }
  }
}

async function fillPromo(promo) {
  // === title, sd, fd, button ===
  fillFirstEmptyInput('[formcontrolname="title"]', promo.title);
  fillFirstEmptyInput('[formcontrolname="shortDescription"]', promo.sd);
  fillFirstEmptyInput('[formcontrolname="buttonText"]', promo.button);
  tinyMceFiller(promo.fulld);
  const tables = document.querySelectorAll('table');

  // === textForUser ===
  if (promo.textForUser?.length && tables.length >= 2) {
    const tbody = tables[1].querySelector('tbody');
    if (tbody) {
      const trs = Array.from(tbody.querySelectorAll('tr'));

      for (let i = 0; i < promo.textForUser.length; i++) {
        const tr = trs[i * 2];
        if (!tr) continue;

        tr.click();

        let input = null;
        for (let j = 0; j < 20; j++) {
          const inputs = Array.from(document.querySelectorAll('[formcontrolname="textForUser"]'));
          input = inputs.find(inp => !inp.value.trim());
          if (input) break;
          await new Promise(r => setTimeout(r, 50));
        }

        if (input) {
          input.value = promo.textForUser[i];
          input.dispatchEvent(new Event('input', { bubbles: true }));
          await new Promise(r => setTimeout(r, 100));
        }
      }
    }
  }

  // === steps ===
  if (promo.steps?.length && tables.length >= 3) {
    const tbody = tables[2].querySelector('tbody');
    if (tbody) {
      const trs = Array.from(tbody.querySelectorAll('tr'));

      for (let i = 0; i < promo.steps.length; i++) {
        const tr = trs[i * 2];
        if (!tr) continue;

        tr.click();

        let input = null;
        for (let j = 0; j < 20; j++) {
          const inputs = Array.from(document.querySelectorAll('[formcontrolname="text"]'));
          input = inputs.find(inp => !inp.value.trim());
          if (input) break;
          await new Promise(r => setTimeout(r, 50));
        }

        if (input) {
          input.value = promo.steps[i];
          input.dispatchEvent(new Event('input', { bubbles: true }));
          await new Promise(r => setTimeout(r, 100));
        }
      }
    }
  }
}

async function fillAdvent(data) {
  // === base ===
  const base = data[0];

  fillFirstEmptyInput('[formcontrolname="title"]', base.title);
  fillFirstEmptyInput('[formcontrolname="subtitle"]', base.subTitle);
  fillFirstEmptyInput('[formcontrolname="buttonTextWhenUnopened"]', base.buttonU);
  fillFirstEmptyInput('[formcontrolname="buttonTextWhenOpened"]', base.buttonO);

  const tables = document.querySelectorAll('table');
  if (tables.length < 2) return;

  const tbody = tables[1].querySelector('tbody');
  if (!tbody) return;

  const trs = Array.from(tbody.querySelectorAll('tr'));

  // === days ===
  for (let i = 0; i < data.length - 1; i++) {
    const day = data[i + 1];
    const tr = trs[i * 2];

    if (!tr) continue;
    tr.click();

    fillFirstEmptyInput('[formcontrolname="dayTitle"]', day.title);
    fillFirstEmptyInput('[formcontrolname="popupTitle"]', day.popupTitle);
    fillFirstEmptyInput('[formcontrolname="giftTitle"]', day.giftTitle);
    fillFirstEmptyInput('[formcontrolname="giftShortDescription"]', day.prizeShortDescription);
    fillFirstEmptyInput('[formcontrolname="giftLongDescription"]', day.prizeLongDescription.trim());
    fillFirstEmptyInput('[formcontrolname="popupButton"]', day.popupButton);
    if (day.variable) fillFirstEmptyInput('[formcontrolname="variableAmount"]', day.variable);

    await new Promise(r => setTimeout(r, 100));
  }

}

async function fillTournament(data) {
  fillFirstEmptyInput('[formcontrolname="title"]', data.title);
  fillFirstEmptyInput('[formcontrolname="participationButtonName"]', data.button);
  tinyMceFiller(data.shortDescription, 0);
  tinyMceFiller(data.shortRules, 1)
}

// === Slot / Text ===
async function fillLink(data) {
  const { url, currencies: fields } = data;
  const selectedFields = fields && fields.length ? fields : CURRENCIES;

  const fillInput = (id, value) => {
    const input = document.getElementById(id);
    if (!input) return;
    input.value = value;
    input.dispatchEvent(new Event('input', { bubbles: true }));
  };

  CURRENCIES.forEach((currency, index) => {
    const input = document.getElementById(`sum${index}`);
    if (!input) return;

    const shouldFill = selectedFields.includes(currency);
    input.value = shouldFill ? formatLink(url) : "";
    input.dispatchEvent(new Event('input', { bubbles: true }));
  });

}

function formatLink(str) {
  const match = str.match(/^(.*?)\((.*)\)$/); 
  if ((!match) || !(match[2].startsWith('/casino'))) return str;
  const name = match[1].trim();
  const url = match[2].trim();
  return `<a target="_blank" href="${url}">${name}</a>`;
}

// === Variables ===
function fillVariables(str) {
  const parsed = parseVariables(str);
  parsed.forEach(({ code, formattedNumber }) => {
    const value = formatCurrency(code, formattedNumber);
    const index = CURRENCIES.indexOf(code);
    if (index !== -1) {
      const input = document.getElementById(`sum${index}`);
      if (input) {
        input.value = value;
        input.dispatchEvent(new Event("input", { bubbles: true }));
      }
    }
  });
}

function parseVariables(str) {
  const normalized = str.replace(/\\/g, "/");

  return normalized.split("/").map(s => s.trim()).filter(Boolean).map(part => {
      const codeMatch = part.match(/\b[A-Z]{3}\b/);
      if (!codeMatch) return null;

      const numberMatch = part.match(/[\d\s.,]+/);
      if (!numberMatch) return null;

      const code = codeMatch[0];
      const rawNumber = numberMatch[0].replace(/\s+/g, "").replace(",", ".");
      const formattedNumber = formatNumber(rawNumber);

      return { code, formattedNumber };
    })
    .filter(Boolean);
}

function formatNumber(numStr) {
  const num = Number(numStr);
  if (Number.isNaN(num)) return numStr;

  return num.toLocaleString("ru-RU", {
      maximumFractionDigits: 10
    })
    .replace(/\u00A0/g, " ");
}

function formatCurrency(code, formattedNumber) {
  const symbol = CURRENCIES_MAP[code] || code;

  if (PREFIX_CURRENCIES.includes(code)) {
    return `${symbol} ${formattedNumber}`;
  }
  return `${formattedNumber} ${symbol}`;
}

// === Steps Images ===
async function fillStepsImages(stepNumber) {
  const steps = Number(stepNumber);
  if (!steps || steps < 3 || steps > 5) return;

  const table = document.querySelector('table');
  const tbody = table.querySelector('tbody');

  const rows = Array.from(tbody.querySelectorAll('tr'));
  let uploadedFiles = 2;

  for (let step = 1; step <= steps; step++) {
    const trIndex = (step - 1) * 2;
    const freshRows = Array.from(
      document.querySelectorAll('table tbody tr')
    );

    const tr = freshRows[trIndex];

    tr.click();
    console.log(`step ${step} clicked`);

    let inputs = await waitForInputs();

    let input1 = inputs[uploadedFiles];
    if (!input1) {
      input1 = inputs[inputs.length - 2]
    }

    await setFile(input1, `steps_images/step${step}.png`, `step${step}`);

    inputs = await waitForInputs();
    let input2 = inputs[uploadedFiles];

    if (!input2) {
      input2 = inputs[inputs.length - 1];
    }

    await setFile(input2, `steps_images/step${step}.webp`, `step${step}`);

    uploadedFiles += 2;
    await sleep(600);
    
  }
}

function sleep(ms) {
  return new Promise(r => setTimeout(r, ms));
}

function waitForInputs() {
  return new Promise(resolve => {
    const check = () => {
      const inputs = Array.from(document.querySelectorAll('input[type="file"]'));
      if (inputs.length > 2) resolve(inputs);
      else setTimeout(check, 100);
    };
    check();
  });
}

async function setFile(input, path, stepName) {
  console.log('set file started', path);
  const url = chrome.runtime.getURL(path);
  const res = await fetch(url);
  const blob = await res.blob();
  const file = new File([blob], path.split('/').pop(), { type: blob.type });
  const dt = new DataTransfer();
  dt.items.add(file);
  input.files = dt.files;

  input.dispatchEvent(new Event('change', { bubbles: true }));

  const regex = new RegExp(`^${stepName}_[a-zA-Z0-9]{4}\\.(png|webp)$`);

  await new Promise(resolve => {
    const observer = new MutationObserver((mutations, obs) => {
      const imgs = Array.from(document.querySelectorAll('img'));
      console.log(imgs.length, imgs)
      for (const img of imgs) {
        const filename = img.src.split('/').pop();
        console.log(filename);
        if (regex.test(filename)) {
          obs.disconnect();
          resolve();
          break;
        }
      }
    });
    observer.observe(document.body, { childList: true, subtree: true });
  });
}

//=== Segments ===
async function fillSegments(data) {
  const inputs = document.querySelectorAll('input');
  let input = inputs[5];
  const { segments, hasText } = formatSegments(data.segments);
  
  if (data.type === "Included") {
    input = inputs[2];
    const testSegment = hasText ? '3405 UP_UP_popup_QAMAR_WL' : '3405'
    segments.push(testSegment);
  }

  let matCount = document.querySelectorAll('mat-chip-row').length + 1;

  for (let i = 0; i < segments.length; i++) {
    input.value = segments[i];
    input.click();
    input.dispatchEvent(new Event('input', { bubbles: true }));

    await sleep(500);

    let option = null;

    if (hasText) {
      option = document.querySelector('.autocomplete-option__content');
    } else {
      option = checkSpanText(segments[i]);
    }
    if (!option) return alert(`Segment ${segments[i]} not found`);

    option.click();

    await new Promise(resolve => {
      const interval = setInterval(() => {
        const chipsCount = document.querySelectorAll('mat-chip-row').length;

        if (chipsCount === matCount) {
          clearInterval(interval);
          matCount++;
          resolve();
        }
      }, 100);
    });
  }
  console.log(input, segments)
}

function formatSegments(s) {
  s = s.trim();

  if (/^[\d\s,\/]+$/.test(s)) {
    return {
      segments: s.split(/[\s,\/]+/).filter(Boolean),
      hasText: false,
    };
  }

  const matches = s.match(/(\d+)\s*(\S+)/g) || [];
  return {
    segments: matches.map(seg => {
      const [, num, text] = seg.match(/(\d+)\s*(\S+)/);
      return `${num} ${text}`;
    }),
    hasText: true,
  };
}

function checkSpanText (num) {
  const options = document.querySelectorAll('.autocomplete-option__content');
  for (let i = 0; i < options.length; i++) {
    const parentSpan = options[i].closest('span');
    const text = parentSpan.textContent.trim();
    const match = text.match(/^\d+/);
    const optionNum = match ? match[0] : null;

    if (optionNum === num) {
      return options[i];
    }
  }
  return null;
}

//=======================================================

const handlers = {
  FILL_PROMO: fillPromo,
  FILL_ADVENT: fillAdvent,
  FILL_LINK: fillLink,
  FILL_VARIABLES: fillVariables,
  FILL_STEPS: fillStepsImages,
  FILL_TOURNAMENT: fillTournament,
  FILL_SEGMENTS: fillSegments,
};

chrome.runtime.onMessage.addListener(({ type, payload }) => {
  handlers[type]?.(payload);
});

//======================================================
chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (msg.type === "PING_EXTENSION") {
    sendResponse({ ok: true });
  }
});