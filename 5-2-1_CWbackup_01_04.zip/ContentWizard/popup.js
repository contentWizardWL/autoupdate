const VERSION_URL = "https://raw.githubusercontent.com/contentWizardWL/autoupdate/main/version.json?v=" + Math.random();
const CURRENT_VERSION = chrome.runtime.getManifest().version;

const API_PROMO = 'https://script.google.com/a/macros/redcore.group/s/AKfycbxzCWD3gZIibWD1MBcQWNtEadVoGrY4khYlIolqLdYb7luFKSzeO5EjikrwjL9j6vfPTg/exec';
const API_ADVENT = 'https://script.google.com/a/macros/redcore.group/s/AKfycbyw3b9PQgku8wBaJwXG_WejSO4uvOzIiXdWx7egnufs5oWTQ-MIDzmf3iCGfNzrP2I7Fg/exec';
const API_RULES = 'https://script.google.com/a/macros/redcore.group/s/AKfycbzZtpCM9exOXoCePxvwo7jjJBd9qVU023YQttUz1L4gfbGXsHcHLonnLdUaw5oOHRyv-g/exec';
const API_TOURNAMENT = 'https://script.google.com/a/macros/redcore.group/s/AKfycbzUSahQuMdotkK8bJWAPen25hLqJIIFyoluNM9BlvXfZJdX3gTI5Agi2E3hyqYaVXSbSg/exec';

const CURRENCIES = ["EUR", "USD", "RUB", "TRY", "KZT", "AZN", "UZS", "CAD", "KGS", "TJS"];
const LANGUAGES = ["RU", "KZ", "AZ", "TR", "EN", "FR", "KG", "TJ", "UZ", "MG"];
const ACTIVITY_TYPE = ['Casino', 'Sport', 'SMM', 'Tournaments'];

const DOC_MODE = {
  show: ['docUrl'],
  placeholder: "https://docs.google.com/document/...",
};

const UI_MAP = {
  promo: DOC_MODE,
  advent: DOC_MODE,
  tournament: DOC_MODE,
  segments: {
    show: ['docUrl', 'segmentsType'],
    placeholder: ['3405 UP_UP_popup_QAMAR_WL'],
  },
  link: {
    show: ['docUrl', 'selectFieldsWrap'],
    placeholder: "slot (/casino/...)",
  },
  hidden: {
    show: ['detailsOptions'],
  },
  variables: {
    show: ['docUrl'],
    placeholder: "20 USD / 1 800 RUB / 1 000 TRY...",
  },
  rules: {
    show: ['rulesSCOption'],
  },
  steps : {
    show: ['stepsCount'],
  },
};

const LANG_COL = Object.freeze({ RU: "B", EN: "C", KZ: "D", TR: "E", AZ: "F", KG: "G", UZ: "H", FR: "I", TJ: "J", MG: "K"});

function generateRuleMap(ranges) {
  const map = {};
  for (const { start, end, startIndex } of ranges) {
    let index = startIndex;
    if (start.startsWith('Hidden')) {
      if (end) {
        const startNum = Number(start.split(' ')[1] || 1);
        const endNum = Number(end.split(' ')[1] || startNum);
        for (let i = startNum; i <= endNum; i++) {
          map[`Hidden ${i}`] = index++;
        }
      } else {
        map['Hidden'] = index++;
      }
      continue;
    }
    const [startMajor, startMinor] = start.split('.').map(Number);
    const [endMajor, endMinor] = end?.split('.')?.map(Number) || [startMajor, startMinor];

    for (let major = startMajor; major <= endMajor; major++) {
      const minorStart = major === startMajor ? startMinor : 1;
      const minorEnd = major === endMajor ? endMinor : 99;
      for (let minor = minorStart; minor <= minorEnd; minor++) {
        map[`${major}.${minor}`] = index++;
        if (major === endMajor && minor === endMinor) break;
      }
    }
  }
  return Object.freeze(map);
}

const CAS_RULE_ROWS_MAP = generateRuleMap([
  {start: '1.1', end: '1.11', startIndex: 4},
  {start: '2.1', end: '2.25', startIndex: 17},
  {start: '3.1', startIndex: 43},
  {start: '4.1', end: '4.2', startIndex: 48},
  {start: 'Hidden', startIndex: 52},
])
const SP_RULE_ROWS_MAP = generateRuleMap([
  { start: '1.1', end: '1.9', startIndex: 3 },
  { start: '2.1', end: '2.18', startIndex: 14 },
  { start: 'Hidden 1', end: 'Hidden 7', startIndex: 33 },
]);
const SMM_RULE_ROWS_MAP = generateRuleMap([
  { start: '1.1', end: '1.9', startIndex: 3 },
  { start: 'Hidden 1', end: 'Hidden 4', startIndex: 13 },
])
const TOURNAMENTS_RULE_ROWS_MAP = Object.freeze({ "Regular": 1 });

const RULE_ROWS_MAP = Object.freeze({
  Casino: CAS_RULE_ROWS_MAP,
  Sport: SP_RULE_ROWS_MAP,
  SMM: SMM_RULE_ROWS_MAP,
  Tournaments: TOURNAMENTS_RULE_ROWS_MAP,
});

let RULE_ROWS = {};
let cell = null;

const chooseFields = document.getElementById("chooseFields");
const currencyOptions = document.getElementById("currencyOptions");
const languageOptions = document.getElementById("languageOptions");
const rulesActivityOption = document.getElementById("rulesSCOption");
const rulesLang = document.getElementById("rulesLang");
const stepsCount = document.getElementById("stepsCount");
const segmentsType = document.getElementById("segmentsType");
const detailsOptions = document.getElementById("detailsOptions");

function createOptionButtons(container, items, options = {}, sp = '_') {
  const { type = "checkbox", name = "", className = "" } = options;
  // options: { type: "checkbox" | "radio", name?: string, className?: string }
  items.forEach(item => {
    const input = document.createElement("input");
    input.type = type;
    if (type === "radio") input.name = name;
    input.id = `${type}${sp}${item}`;
    input.value = item;
    input.style.display = "none";

    const label = document.createElement("label");
    label.htmlFor = input.id;
    label.className = `toggle-btn ${className}`.trim();
    label.textContent = item;

    container.appendChild(input);
    container.appendChild(label);
  });
}

function createRuleButtons() {
  const container = document.getElementById('rulesNumbers');
  container.innerHTML = '';
  let currentGroup = null;
  let groupDiv = null;
  let group = 0;
  Object.keys(RULE_ROWS).forEach(rule => {
    if (rule.includes(".")) group = rule.split(".")[0];
    else group = 'hidden';

    if (group !== currentGroup) {
      currentGroup = group;

      groupDiv = document.createElement("div");
      groupDiv.className = "rules-group-active";
      container.appendChild(groupDiv);
    }
    const input = document.createElement('input');
    input.type = 'radio';
    input.name = 'ruleNumber';
    input.value = rule;
    input.id = `rule_${rule}`;

    const label = document.createElement('label');
    label.htmlFor = input.id;
    label.textContent = rule;
    label.className = 'toggle-btn currency';

    groupDiv.appendChild(input);
    groupDiv.appendChild(label);
  });
}

const OPTION_BUTTONS = [
  [currencyOptions, CURRENCIES, { type: "checkbox", className: "currency" }],
  [languageOptions, LANGUAGES, { type: "radio", name: "languages", className: "currency" }],
  [rulesActivityOption, ACTIVITY_TYPE, { type: "radio", name: "activity", className: "currency" }],
  [rulesLang, LANGUAGES, { type: "radio", name: "rulesLang", className: "currency" }, '-'],
  [stepsCount, ['3','4','5'], { type: "radio", name: "stepsCount", className: "currency" }],
  [segmentsType, ['Included', 'Excluded'], {type: "radio", name: "segmentsType", className: "currency"}],
  [detailsOptions, ['Add', 'Remove'], {type: "radio", name: "detailsOptions", className: "currency"}],
];

OPTION_BUTTONS.forEach(args => createOptionButtons(...args));

function updateUI() {
  const type = document.querySelector('input[name="type"]:checked')?.value;
  const config = UI_MAP[type] || {};

  const textField = document.getElementById('docUrl');
  textField.style.display = 'none';
  
  document.querySelectorAll('.option-group').forEach(el => {
    el.style.display = 'none';
  });

  document.querySelectorAll('.option-group input').forEach(input => {
    input.checked = false;
  });

  const selectFieldsWrap = document.getElementById('selectFieldsWrap');

  chooseFields.checked = false;
  selectFieldsWrap.style.display = 'none';
  currencyOptions.style.display = 'none';

  (config.show || []).forEach(id => {
    const el = document.getElementById(id);
    if (el) el.style.display = "flex";
  });

  if (config.placeholder) {
    const docInput = document.getElementById('docUrl');
    docInput.placeholder = config.placeholder;
    docInput.value = '';
  }
}

document.addEventListener("change", (e) => {
  const target = e.target;

  // === detailsOptions ===
  if (target.closest("#detailsOptions") && target.matches('input[type="radio"]')) {
    document.getElementById("languageOptions").style.display = target.value === 'Add' ? "flex" : "none";
  };

  // === rulesActivityOption ===
  if (target.closest("#rulesSCOption") && target.matches('input[type="radio"]')) {
    RULE_ROWS = RULE_ROWS_MAP[target.value];
    createRuleButtons();
    rulesLang.style.display = "flex";
  };

  // === rulesLang ===  
  if (target.closest("#rulesLang") && target.matches('input[type="radio"]')) {
    document.getElementById("rulesNumbers").style.display = "flex";
    document.querySelectorAll('.rules-group-active').forEach(el => {
      el.style.display = "flex";
      el.style.flexWrap = "wrap";
    });
    document.querySelectorAll('input[name="ruleNumber"]').forEach(input => input.checked = false);
  };

  // === rulesNumbers ===
  if (target.closest("#rulesNumbers") && target.matches('input[name="ruleNumber"]')) {
    const selectedRule = document.querySelector('input[name="ruleNumber"]:checked')?.value;
    const selectedLang = document.querySelector('input[name="rulesLang"]:checked')?.value;
    const column = LANG_COL[selectedLang];
    const row = RULE_ROWS[selectedRule];
    cell = `${column}${row}`;
  };

  // === chooseFields ===
  if (target.id === "chooseFields") {
    currencyOptions.style.display = target.checked ? "flex" : "none";
  };


  // === updateUI for type radios ===
  if (target.matches('input[name="type"]')) {
    updateUI();
  };
});

function sendToActiveTab(messageType, payload) {
  chrome.tabs.query({ active: true, currentWindow: true }, ([tab]) => {
    if (!tab) return;

    chrome.tabs.sendMessage(tab.id, {
      type: messageType,
      payload
    });
  });
}

document.getElementById('load').addEventListener('click', async () => {
  const inputValue = document.getElementById('docUrl').value.trim();

  const type = document.querySelector('input[name="type"]:checked').value;

  if (type === 'link') {
    let selectedCurrencies = [];
    if (chooseFields.checked) {
      selectedCurrencies = [
        ...currencyOptions.querySelectorAll('input[type="checkbox"]:checked')
      ].map(input => input.value);
    }
    sendToActiveTab('FILL_LINK', { url: inputValue, currencies: selectedCurrencies, });
    return;
  }

  if (type === 'variables') {
    sendToActiveTab('FILL_VARIABLES', inputValue);
    return;
  }

  if (type === 'steps') {
    const stepNumber = document.querySelector('#stepsCount input[type="radio"]:checked')?.value;
    sendToActiveTab('FILL_STEPS', stepNumber);
    return;
  }

  if (type === 'segments') {
    const segment = document.querySelector('#segmentsType input[type="radio"]:checked')?.value;
    sendToActiveTab('FILL_SEGMENTS', { segments: inputValue, type: segment, });
    return;
  }

  if (type === 'hidden') {
  const selectedOption = document.querySelector('#detailsOptions input[type="radio"]:checked').value
  const selectedLanguage = selectedOption === 'Add' ? document.querySelector('#languageOptions input[type="radio"]:checked').value : '';
  
  chrome.tabs.query({ active: true, currentWindow: true }, ([tab]) => {

    chrome.scripting.executeScript({
      target: { tabId: tab.id },
      world: "MAIN",
      func: (language, option) => {
        const HIDDEN_PART = {
          RU: "Правила",
          EN: "Rules",
          AZ: "Qaydalar",
          FR: "Règles",
          KZ: "Ережелер",
          KG: "Эрежелер",
          TJ: "Қоидаҳо",
          TR: "Kurallar",
          UZ: "Qoidalar",
          MG: "Дүрэм",
        }
        const editor = window.tinymce?.activeEditor;

        editor.focus();
        editor.undoManager.transact(() => {
          const content = editor.getContent();
          if (option === 'Add') {
            const parts = content.split('<p>&nbsp;</p>');
            const before = parts[0] || '';
            const after = parts[1] || '';
            editor.setContent(before + `<details><summary>${HIDDEN_PART[language]}</summary>` + after + `</details>`);
          } else {
            const parts = content.split('<details>');
            const before = parts[0] || '';
            const after = parts[1].replace(/<summary>[\s\S]*?<\/summary>/gi, '<p>&nbsp;</p>').replace(/<\/details>\s*$/i, '') || '';
            editor.setContent(before + after);
          }
        });
      },
      args: [selectedLanguage, selectedOption]
    });
  });
  return;
  }
  
  const activity = document.querySelector('input[name="activity"]:checked')?.value;

  if (type === 'rules') {
    if (!activity || !cell) return;

    let data;
    try {
      const res = await fetch(`${API_RULES}?activity=${encodeURIComponent(activity)}&cell=${encodeURIComponent(cell)}`);
      data = await res.json();
    } catch (err) {
      console.error(err);
      return;
    }

    chrome.tabs.query({ active: true, currentWindow: true }, ([tab]) => {
      if (!tab) return;

      chrome.scripting.executeScript({
        target: { tabId: tab.id },
        world: "MAIN",
        args: [data],
        func: (rulesData) => {
          const editor = window.tinymce?.activeEditor;
          if (!editor) return;

          let text = '';
          
          for (let i = 0; i < rulesData.length; i++) {
            text += rulesData[i];
          }
          if (text === "<ol></ol>" || !text) text = 'Не верный формат правил.'
          editor.focus();
          const currentContent = editor.getContent();
          editor.setContent(currentContent + text);
        }
      });
    });
  }
  
  const CONFIG = {
    promo: { api: () => `${API_PROMO}?url=${encodeURIComponent(inputValue)}`, message: 'FILL_PROMO' },
    advent: { api: () => `${API_ADVENT}?url=${encodeURIComponent(inputValue)}`, message: 'FILL_ADVENT' },
    tournament : { api: () => `${API_TOURNAMENT}?url=${encodeURIComponent(inputValue)}`, message: 'FILL_TOURNAMENT' },
  };

  const cfg = CONFIG[type];
  if (!cfg) return;

  try {
    const res = await fetch(cfg.api());
    const data = await res.json();
    console.log(data);
    if (data.error) {
      console.error(data.error);
      return;
    }

    chrome.tabs.query({ active: true, currentWindow: true }, async ([tab]) => {
      if (!tab) return;
      chrome.tabs.sendMessage(tab.id, { type: cfg.message, payload: data });
    });

  } catch (err) {
    console.error(err);
  }
});

// ==============

initUpdateCheck();

async function initUpdateCheck() {
  try {
    const r = await fetch(VERSION_URL, { cache: "no-store" });
    if (!r.ok) return;
    const data = await r.json();
    const latest = data.version;
    const download = data.download;
    const updates = data.updates.map(u => `<div>${u}</div>`).join('<br>');
    if (!latest) return;

    const box = document.getElementById("updateBox");

    if (latest !== CURRENT_VERSION) {
      box.style.display = "block";
      box.innerHTML = `
        <div style="
          display: flex;
          flex-direction: column;
          align-items: center;
          justify-content: center;
          background: #0f172a;
          color: #e5e7eb;
          padding: 8px 12px;
          border-radius: 6px;
          font-size: 12px;
          border: 1px solid #334155;
          width: 100%;
          box-sizing: border-box;">

          <span>Better than before. Version ${latest} is here</span>
          <br>
          ${updates}
          
          <button id="downloadUpdate" class="toggle-btn" style="
            background: #020617;
            color: #e5e7eb;
            border-radius: 6px;
            padding: 4px 8px;
            cursor: pointer;
            border: 1px solid #334155;
            font-size: 12px;
            white-space: nowrap;
            flex: 0 0 auto;
            width: auto;
            align-self: center;">Get it now</button>
        </div>
      `;

      document.getElementById("downloadUpdate").onclick = () => {
        chrome.tabs.create({ url: download });
      };
      return;
    }

    box.style.display = "none";
    box.innerHTML = '';
    checkReloadNeeded(box);

  } catch (e) {
    console.log("update check fail", e);
  }
}

function checkReloadNeeded(box) {
  chrome.tabs.query({ active: true, currentWindow: true }, ([tab]) => {
    chrome.tabs.sendMessage(tab.id, { type: "PING_EXTENSION" }, (res) => {
      if (chrome.runtime.lastError || !res) {
        box.style.display = "block";
        box.innerHTML = `
          <div style="
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            gap: 6px;
            background: #0f172a;
            color: #e43333ff;
            padding: 8px 12px;
            border-radius: 6px;
            font-size: 12px;
            border: 1px solid #334155;
            width: 100%;
            box-sizing: border-box;
          ">
            <span style="
              opacity: 0;
              animation: fadeBlink 3.5s ease-in-out infinite;
            ">
              It’s not broken. Just refresh the page.
            </span>
          </div>

          <style>
            @keyframes fadeBlink {
              0%   { opacity: 0.3; }
              50%  { opacity: 1; }
              100% { opacity: 0.3; }
            }
          </style>
        `;
      }
    });
  });
}