init();
async function init() {
  const domain = await getActiveTabUrl();
  main(domain);
}

function getActiveTabUrl() {
  return new Promise((resolve) => {
    chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
      resolve(tabs[0]?.url || '');
    });
  });
};

function main(domain) {

const isWL = domain.includes('pincowin');
const isCOM = domain.includes('tech-pu') || domain.includes('spacer-way');

// === VERSION CHECK ===
const VERSION_URL = "https://raw.githubusercontent.com/contentWizardWL/autoupdate/main/version.json?v=" + Math.random();
const CURRENT_VERSION = chrome.runtime.getManifest().version;
document.querySelector('h1').textContent = `Content Wizard v${CURRENT_VERSION}`;

// === GOOGLE API ===
const API_PROMO = 'https://script.google.com/a/macros/redcore.group/s/AKfycbw2vpUb2YI6MO1kPFY-bzdPUvOBCCFzWdM_YVQHKxKCD90i9Uf1DV25AZkDHa3t1470kw/exec';
const API_ADVENT = 'https://script.google.com/a/macros/redcore.group/s/AKfycbzzD9jaGn0UQBFIF8jtGMGSjtJiSH182R8FUPMIyq91ushUAr9-Gx6t5u687Jvtuf6g8Q/exec';
const API_RULES = 'https://script.google.com/a/macros/redcore.group/s/AKfycbxVnx--HbDg0_A24PUWVbJtT_hh-dHWvUCranY8OMQLaOvx6k3ArwdjK-zW1CBPZ9_uvg/exec';
const API_TOURNAMENT = 'https://script.google.com/a/macros/redcore.group/s/AKfycbx68epeFWChFcYVYLucMsHBGP4IV0NWYz4Ek7qWW6IKED3b4btUoVz6hgtLu5zEXn0h7g/exec';
const API_PRETTY = 'https://script.google.com/a/macros/redcore.group/s/AKfycbwtuEU04QTxlvXaLbySkSuxVnxVvXgZo-mM6tOz-zrlBzrdh0AtRP9pfGWzy0ibezDJ/exec';

// === flatpicker ===
flatpickr("#startDate", {
  enableTime: true,
  time_24hr: true,
  dateFormat: "F j, Y H:i",
  minuteIncrement: 1,
  onOpen: function () { if (Number(document.body.scrollHeight) < 515) document.body.style.height = "515px"; },
  onClose: function () { document.body.style.height = ""; },
  onReady: function (selectedDates, dateStr, instance) {
    const btn = document.createElement("button");
    btn.textContent = "OK";
    btn.style.cssText = `
      width: 10%;
      margin-top: 0px;
      padding: 5px;
      font-size: 12px;
      cursor: pointer;
      display: block;
      margin-left: 87%;
      margin-bottom: 10px;
    `;
    btn.addEventListener("click", () => {
      instance.close();
    });
    instance.calendarContainer.appendChild(btn);
  }
});

flatpickr("#endDate", {
  enableTime: true,
  time_24hr: true,
  dateFormat: "F j, Y H:i",
  minuteIncrement: 1,
  onOpen: function () { if (Number(document.body.scrollHeight) < 515) document.body.style.height = "515px"; },
  onClose: function () { document.body.style.height = ""; },
  onReady: function (selectedDates, dateStr, instance) {
    const btn = document.createElement("button");
    btn.textContent = "OK";
    btn.style.cssText = `
      width: 10%;
      margin-top: 0px;
      padding: 5px;
      font-size: 12px;
      cursor: pointer;
      display: block;
      margin-left: 87%;
      margin-bottom: 10px;
    `;
    btn.addEventListener("click", () => {
      instance.close();
    });
    instance.calendarContainer.appendChild(btn);
  }
});

const DOC_MODE = {
  show: ['docUrl'],
  placeholder: "https://docs.google.com/document/...",
};

const UI_MAP = {
  promo: DOC_MODE,
  advent: { 
    show: ['docUrl', 'adventOptions'],
    placeholder: "https://docs.google.com/document/...",
  },
  tournament: { 
    show: ['docUrl', 'tournamentOptions'],
    placeholder: "https://docs.google.com/document/...",
  },
  locales: {
    show: ['docUrl'],
    placeholder: ['AZ, TR, KZ...'],
  },
  segments: {
    show: ['docUrl', 'segmentsVer'],
    placeholder: ['3405 UP_UP_popup_QAMAR_WL'],
  },
  link: {
    show: ['docUrl', 'selectFieldsWrap'],
    placeholder: "slot (/casino/...)",
  },
  hidden: {
    show: ['detailsOptions'],
  },
  sliders: {
    show: ['slidersOp', 'docUrl'],
    placeholder: ['Full slider text'],
  },
  variables: {
    show: ['docUrl'],
    placeholder: "100 EUR / 100 USD / 1 000 TRY...",
  },
  rules: {
    show: ['rulesSCOption'],
  },
  steps : {
    show: ['stepsCount'],
  },
  pretty: {
    show: ['prettyOp'],
  },
};

function generateRuleMap(ranges) {
  const map = {};
  for (const { start, end, startIndex } of ranges) {
    let index = startIndex;
    if (start.startsWith('Hidden')) {
      if (end) {
        const startNum = Number(start.split(' ')[1] || 1);
        const endNum = Number(end.split(' ')[1] || startNum);
        for (let i = startNum; i <= endNum; i++) {
          map[`Hidden ${i}`] = index++;
        }
      } else {
        map['Hidden'] = index++;
      }
      continue;
    }
    const [startMajor, startMinor] = start.split('.').map(Number);
    const [endMajor, endMinor] = end?.split('.')?.map(Number) || [startMajor, startMinor];

    for (let major = startMajor; major <= endMajor; major++) {
      const minorStart = major === startMajor ? startMinor : 1;
      const minorEnd = major === endMajor ? endMinor : 99;
      for (let minor = minorStart; minor <= minorEnd; minor++) {
        map[`${major}.${minor}`] = index++;
        if (major === endMajor && minor === endMinor) break;
      }
    }
  }
  return Object.freeze(map);
}

const CAS_RULE_ROWS_MAP_WL = generateRuleMap([
  {start: '1.1', end: '1.11', startIndex: 4},
  {start: '2.1', end: '2.25', startIndex: 17},
  {start: '3.1', startIndex: 43},
  {start: '4.1', end: '4.2', startIndex: 48},
  {start: 'Hidden', startIndex: 52},
])
const SP_RULE_ROWS_MAP_WL = generateRuleMap([
  { start: '1.1', end: '1.9', startIndex: 3 },
  { start: '2.1', end: '2.19', startIndex: 14 },
  { start: 'Hidden 1', end: 'Hidden 7', startIndex: 34 },
]);
const SMM_RULE_ROWS_MAP_WL = generateRuleMap([
  { start: '1.1', end: '1.9', startIndex: 3 },
  { start: '2.1', startIndex: 12 },
  { start: 'Hidden 1', end: 'Hidden 4', startIndex: 14 },
])
const TOURNAMENTS_RULE_ROWS_MAP_WL = Object.freeze({ "Regular": 1 });

const CAS_RULE_ROWS_MAP_COM = generateRuleMap([
  { start: '1.1', end: '1.9', startIndex: 5 },
  { start: '2.1', end: '2.30', startIndex: 15 },
  { start: '3.1', startIndex: 47 },
  { start: '4.1', startIndex: 49 },
  { start: 'Hidden', startIndex: 50 },
])
const SP_RULE_ROWS_MAP_COM = generateRuleMap([
  { start: '1.1', end: '1.10', startIndex: 3 },
  { start: '2.1', end: '2.26', startIndex: 14 },
  { start: 'Hidden 1', end: 'Hidden 7', startIndex: 41 },
]);
const SMM_RULE_ROWS_MAP_COM = generateRuleMap([
  { start: '1.1', end: '1.9', startIndex: 3 },
  { start: '2.0', end: '2.2', startIndex: 10 },
  { start: '2.3', end: '2.7', startIndex: 14 },
  { start: 'Hidden 1', end: 'Hidden 3', startIndex: 20 },
])
const TOURNAMENTS_RULE_ROWS_MAP_COM = Object.freeze({ "Regular": 3 });

const RULE_ROWS_MAP_WL = Object.freeze({
  Casino: CAS_RULE_ROWS_MAP_WL,
  Sport: SP_RULE_ROWS_MAP_WL,
  SMM: SMM_RULE_ROWS_MAP_WL,
  Tournaments: TOURNAMENTS_RULE_ROWS_MAP_WL,
});

const RULE_ROWS_MAP_COM = Object.freeze({
  Casino: CAS_RULE_ROWS_MAP_COM,
  Sport: SP_RULE_ROWS_MAP_COM,
  SMM: SMM_RULE_ROWS_MAP_COM,
  Tournaments: TOURNAMENTS_RULE_ROWS_MAP_COM,
});

const RULE_ROWS_MAP = isCOM ? RULE_ROWS_MAP_COM : RULE_ROWS_MAP_WL;

let RULE_ROWS = {};

const inputField = document.getElementById("docUrl");
const chooseFields = document.getElementById("chooseFields");
const currencyOptions = document.getElementById("currencyOptions");
const languageOptions = document.getElementById("languageOptions");
const rulesActivityOption = document.getElementById("rulesSCOption");
const rulesLang = document.getElementById("rulesLang");
const stepsCount = document.getElementById("stepsCount");
const segmentsType = document.getElementById("segmentsType");
const segmentsVer = document.getElementById('segmentsVer');
const detailsOptions = document.getElementById("detailsOptions");
const pretty = document.getElementById('prettyOp');
const tournamentOptions = document.getElementById('tournamentOptions');
const pointsInput = document.getElementById('tournamentPointsInput');
const slidersOp = document.getElementById('slidersOp');
const textArea = document.getElementById('sliderText');
const slidersMT = document.getElementById('slidersMT');
const adventOptions = document.getElementById('adventOptions');

function createOptionButtons(container, items, options = {}, sp = '_') {
  const { type = "checkbox", name = "", className = "" } = options;
  // options: { type: "checkbox" | "radio", name?: string, className?: string }
  items.forEach(item => {
    const input = document.createElement("input");
    input.type = type;
    if (type === "radio") input.name = name;
    input.id = `${type}${sp}${item}`;
    input.value = item;
    input.style.display = "none";
    const label = document.createElement("label");
    label.htmlFor = input.id;
    label.className = `toggle-btn ${className}`.trim();
    label.textContent = item;
    container.appendChild(input);
    container.appendChild(label);
  });
}

function createRuleButtons() {
  const container = document.getElementById('rulesNumbers');
  container.innerHTML = '';
  let currentGroup = null;
  let groupDiv = null;
  let group = 0;
  Object.keys(RULE_ROWS).forEach(rule => {
    if (rule.includes(".")) group = rule.split(".")[0];
    else group = 'hidden';

    if (group !== currentGroup) {
      currentGroup = group;

      groupDiv = document.createElement("div");
      groupDiv.className = "rules-group-active";
      container.appendChild(groupDiv);
    }
    const input = document.createElement('input');
    input.type = 'radio';
    input.name = 'ruleNumber';
    input.value = rule;
    input.id = `rule_${rule}`;

    const label = document.createElement('label');
    label.htmlFor = input.id;
    label.textContent = rule;
    label.className = 'toggle-btn currency';

    groupDiv.appendChild(input);
    groupDiv.appendChild(label);
  });
}

const CURRENCIES_WL = ["EUR", "USD", "RUB", "TRY", "KZT", "AZN", "UZS", "CAD", "KGS", "TJS"];
const CURRENCIES_COM = ["EUR", "USD", "KZT", "AZN", "UZS", "INR", "CLP", "CAD", "MXN", "BDT", "GTQ", "BOB", "HNL", "NGN", "KSH", "CRC", "NIO", "CDF"];

const LANGUAGES_WL = ["RU", "KZ", "AZ", "TR", "EN", "FR", "KG", "TJ", "UZ", "MG"];
const LANGUAGES_COM = ["RU", "EN", "AZ", "KZ", "UZ", "HI", "BN", "ES", "FR",];
const RULES_LANGUAGES_COM = ["RU", "EN", "ES", "KZ", "UZ", "AZ", "HI", "BN", "FR (CD)", "TR", "BR-PT", "FR"];

const ACTIVITY_TYPE = ['Casino', 'Sport', 'SMM', 'Tournaments'];

const SEGMENTS_OP_COM = ['Included', 'Excluded', 'Excl Casino', 'Excl Sport', 'Excl CORE', 'Excl AZ', 'Excl KZ-UZ', 'Excl IN-BD', 'Excl LATAM'];
const SEGMENTS_OP_WL = ['Included', 'Excluded', 'Excl Casino', 'Excl Sport'];

const segmentsOp = isCOM ? SEGMENTS_OP_COM : SEGMENTS_OP_WL;
const languagesOp = isCOM ? LANGUAGES_COM : isWL ? LANGUAGES_WL : [];
const rulesLanguagesOp = isCOM ? RULES_LANGUAGES_COM : isWL ? LANGUAGES_WL : [];
const variablesOp = isCOM ? CURRENCIES_COM : isWL ? CURRENCIES_WL : [];

const OPTION_BUTTONS = [
  [currencyOptions, variablesOp, { type: "checkbox", className: "currency" }],
  [languageOptions, languagesOp, { type: "radio", name: "languages", className: "currency" }],
  [rulesActivityOption, ACTIVITY_TYPE, { type: "radio", name: "activity", className: "currency" }],
  [rulesLang, rulesLanguagesOp, { type: "radio", name: "rulesLang", className: "currency" }, '-'],
  [stepsCount, ['3','4','5'], { type: "radio", name: "stepsCount", className: "currency" }],
  [segmentsVer, ['V.1', 'V.2',], { type: "radio", name: "segmentsVer", className: "currency" },],
  [segmentsType, segmentsOp, {type: "radio", name: "segmentsType", className: "currency"}],
  [detailsOptions, ['Add', 'Remove'], { type: "radio", name: "detailsOptions", className: "currency" }],
  [pretty, ['Casino Template', 'Sport Template', 'Variables'], { type: "radio", name: "pretty", className: "currency" }, '-'],
  [tournamentOptions, ['Page', 'Games ID', 'Currencies'], { type: "radio", name: "tournamentOptions", className: "currency" }],
  [slidersOp, ['Text', 'Link', 'Marketing Type',], { type: "radio", name: "slidersOp", className: "currency" }],
  [slidersMT, ['Tournament', 'Release', 'Pre-Release'], { type: "radio", name: "slidersMT", className: "currency" }],
  [adventOptions, ['Page', 'Dates',], { type: "radio", name: "slidersMT", className: "currency" }, '-'],
];

OPTION_BUTTONS.forEach(args => createOptionButtons(...args));

function updateUI() {
  const type = document.querySelector('input[name="type"]:checked')?.value;
  const config = UI_MAP[type] || {};

  inputField.style.display = 'none';
  
  document.querySelectorAll('.option-group').forEach(el => {
    el.style.display = 'none';
  });

  document.querySelectorAll('.extra-input').forEach(el => {
    el.style.display = 'none';
  })

  document.querySelectorAll('.option-group input').forEach(input => {
    input.checked = false;
  });

  document.getElementById('datePicker').style.display = "none";

  const selectFieldsWrap = document.getElementById('selectFieldsWrap');

  chooseFields.checked = false;
  selectFieldsWrap.style.display = 'none';
  currencyOptions.style.display = 'none';
  textArea.style.display = 'none';

  (config.show || []).forEach(id => {
    const el = document.getElementById(id);
    if (el) el.style.display = "flex";
  });

  if (config.placeholder) {
    inputField.placeholder = config.placeholder;
    inputField.value = '';
  }
}

async function checkPointsInput() {
  const [tab] = await chrome.tabs.query({
    active: true,
    currentWindow: true
  });
  const response = await chrome.tabs.sendMessage(tab.id, {
    action: 'checkPointsInput'
      });
  return response.exists;
}

document.addEventListener("change", async(e) => {
  const target = e.target;

  // === adventOptions ===
  if (target.closest('#adventOptions') && target.matches('input[type="radio"]')) {
    document.getElementById('datePicker').style.display = target.value === "Dates" ? "flex" : "none";
    inputField.style.display = target.value === "Dates" ? "none" : "flex";
  }

  // === sheet map ===
  if (target.closest('#prettyOp') && target.matches('input[type="radio"]')) {
    inputField.style.display = target.value === "Variables" ? "flex" : "none";
    if (target.value === "Variables") inputField.placeholder = '€ 1000 EUR / $ 1000 USD /...'
  }

  // === sliders ===
  if (target.closest("#slidersOp") && target.matches('input[type="radio"]')) {
    textArea.style.display = target.value === "Text" ? "flex" : "none";
    inputField.style.display = target.value === "Link" || target.value === "Marketing Type" ? "flex" : "none";
    if (target.value === "Marketing Type") {
      inputField.value = '';
      inputField.placeholder = "Provider's logo link";
    }
    if (target.value === "Link") {
      inputField.placeholder = "Activity link";
      inputField.value = '';
    }
    slidersMT.style.display = target.value === "Marketing Type" ? "flex" : "none";
  }
  // === tournamentOptions ===
  if (target.closest("#tournamentOptions") && target.matches('input[type="radio"]')) {   
    pointsInput.style.display = (target.value === 'Currencies' && await checkPointsInput())  ? 'flex' : 'none';

    if (target.value === 'Games ID') inputField.placeholder = 'SLOT ID /casino/...';
    else if (target.value === 'Currencies') inputField.placeholder = '€ 1 EUR / $ 1 USD /...';
    else inputField.placeholder = 'https://docs.google.com/document/...';
  };

  // === Segments ===
  if (target.closest("#segmentsVer") && target.matches('input[type="radio"]')) {
    segmentsType.style.display = target.value === 'V.1' || target.value === 'V.2' ? "flex" : "none";
  };
  if (target.closest("#segmentsType") && target.matches('input[type="radio"]')) {
    inputField.style.display = (segmentsOp.slice(2, segmentsOp.length).includes(target.value)) ? "none" : "flex";
  };

  // === detailsOptions ===
  if (target.closest("#detailsOptions") && target.matches('input[type="radio"]')) {
    languageOptions.style.display = target.value === 'Add' ? "flex" : "none";
  };

  // === rulesActivityOption ===
  if (target.closest("#rulesSCOption") && target.matches('input[type="radio"]')) {
    RULE_ROWS = RULE_ROWS_MAP[target.value];
    createRuleButtons();
    rulesLang.style.display = "flex";
  };

  // === rulesLang ===  
  if (target.closest("#rulesLang") && target.matches('input[type="radio"]')) {
    document.getElementById("rulesNumbers").style.display = "flex";
    document.querySelectorAll('.rules-group-active').forEach(el => {
      el.style.display = "flex";
      el.style.flexWrap = "wrap";
    });
  };

  // === chooseFields ===
  if (target.id === "chooseFields") {
    currencyOptions.style.display = target.checked ? "flex" : "none";
  };

  // === updateUI for type radios ===
  if (target.matches('input[name="type"]')) {
    updateUI();
  };
});

function sendToActiveTab(messageType, payload) {
  chrome.tabs.query({ active: true, currentWindow: true }, ([tab]) => {
    if (!tab) return;

    chrome.tabs.sendMessage(tab.id, {
      type: messageType,
      payload
    });
  });
}

document.getElementById('load').addEventListener('click', async () => {
  const inputValue = inputField.value.trim();

  const type = document.querySelector('input[name="type"]:checked').value;

  if (type === 'link') {
    let selectedCurrencies = [];
    if (chooseFields.checked) {
      selectedCurrencies = [
        ...currencyOptions.querySelectorAll('input[type="checkbox"]:checked')
      ].map(input => input.value);
    }
    sendToActiveTab('FILL_LINK', { url: inputValue, currencies: selectedCurrencies, });
    return;
  }

  if (type === 'variables') {
    sendToActiveTab('FILL_VARIABLES', inputValue);
    return;
  }

  if (type === 'steps') {
    const stepNumber = document.querySelector('#stepsCount input[type="radio"]:checked')?.value;
    sendToActiveTab('FILL_STEPS', stepNumber);
    return;
  }

  if (type === 'segments') {
    const segment = document.querySelector('#segmentsType input[type="radio"]:checked')?.value;
    const version = document.querySelector('#segmentsVer input[type="radio"]:checked')?.value === 'V.1' ? 1 : 2;
    sendToActiveTab('FILL_SEGMENTS', { segments: inputValue, type: segment, version});
    return;
  }

  if (type === 'locales') {
    sendToActiveTab('FILL_LOCALES', inputValue);
    return;
  }

  if (type === 'hidden') {
    const selectedOption = document.querySelector('#detailsOptions input[type="radio"]:checked').value
    const selectedLanguage = selectedOption === 'Add' ? document.querySelector('#languageOptions input[type="radio"]:checked').value : '';
    
    chrome.tabs.query({ active: true, currentWindow: true }, ([tab]) => {

      chrome.scripting.executeScript({
        target: { tabId: tab.id },
        world: "MAIN",
        func: (language, option) => {
          const HIDDEN_PART = {
            RU: "Правила",
            EN: "Rules",
            AZ: "Qaydalar",
            FR: "Règles",
            KZ: "Ережелер",
            KG: "Эрежелер",
            TJ: "Қоидаҳо",
            TR: "Kurallar",
            UZ: "Qoidalar",
            MG: "Дүрэм",
            HI: "नियम",
            ES: "Reglas",
            BN: "নিয়ম",
          }
          const editor = window.tinymce?.activeEditor;

          editor.focus();
          editor.undoManager.transact(() => {
            const content = editor.getContent();
            if (option === 'Add') {
              const parts = content.split('<p>&nbsp;</p>');
              const before = parts[0] || '';
              const after = parts[1] || '';
              editor.setContent(before + `<details><summary>${HIDDEN_PART[language]}</summary>` + after + `</details>`);
            } else {
              const parts = content.split('<details>');
              const before = parts[0] || '';
              const after = parts[1].replace(/<summary>[\s\S]*?<\/summary>/gi, '<p>&nbsp;</p>').replace(/<\/details>\s*$/i, '') || '';
              editor.setContent(before + after);
            }
          });
        },
        args: [selectedLanguage, selectedOption]
      });
    });
    return;
  }
  
  if (type === 'rules') {   
    const LANG_COL_WL = Object.freeze({ RU: "B", EN: "C", KZ: "D", TR: "E", AZ: "F", KG: "G", UZ: "H", FR: "I", TJ: "J", MG: "K"});
    const LANG_COL_COM = Object.freeze({ RU: "B", EN: "C", ES: "D", KZ: "E", UZ: "F", AZ: "G", HI: "H", BN: "I", 'FR (CD)': "J", TR: "K", 'BR-PT': 'L', FR: 'M' });
    const LANG_COL = isCOM ? LANG_COL_COM : LANG_COL_WL;
    const comSelector = isCOM ? 'COM' : '';

    const activity = document.querySelector('input[name="activity"]:checked')?.value + comSelector;
    const selectedRule = document.querySelector('input[name="ruleNumber"]:checked')?.value;
    const selectedLang = document.querySelector('input[name="rulesLang"]:checked')?.value;
    const column = LANG_COL[selectedLang];
    const row = RULE_ROWS[selectedRule];
    const cell = `${column}${row}`;
    console.log(`act - ${activity}, rule - ${selectedRule}, lang - ${selectedLang}, col - ${column}, row - ${row}, cell - ${cell}, isCom - ${isCOM}, comsel - ${comSelector}`)

    let data;
    try {
      const res = await fetch(`${API_RULES}?activity=${encodeURIComponent(activity)}&cell=${encodeURIComponent(cell)}`);
      data = await res.json();
    } catch (err) {
      console.error(err);
      return;
    }

    chrome.tabs.query({ active: true, currentWindow: true }, ([tab]) => {
      if (!tab) return;

      chrome.scripting.executeScript({
        target: { tabId: tab.id },
        world: "MAIN",
        args: [data],
        func: (rulesData) => {
          const editor = window.tinymce?.activeEditor;
          if (!editor) return;

          let text = '';
          
          for (let i = 0; i < rulesData.length; i++) {
            text += rulesData[i];
          }
          if (text === "<ol></ol>" || !text) text = 'Не верный формат правил.'
          editor.focus();
          const currentContent = editor.getContent();
          editor.setContent(currentContent + text);
        }
      });
    }); return;
  }

  if (type === "sliders") {
    const text = textArea.value.split('\n').map(line => line.trim()).filter(Boolean)?? '';
    const link = inputValue?? '';
    const option = document.querySelector('#slidersOp input[type="radio"]:checked')?.value?? '';
    const marketOption = option === "Marketing Type" ? document.querySelector('#slidersMT input[type="radio"]:checked')?.value : '';
    sendToActiveTab('FILL_SLIDER', { text, link, option, marketOption });
    return
  }

  const CONFIG = {
    promo: { 
      api: () => `${API_PROMO}?url=${encodeURIComponent(inputValue)}`, 
      message: 'FILL_PROMO' 
    },
    advent: { 
      api: () => `${API_ADVENT}?url=${encodeURIComponent(inputValue)}`, 
      message: adventOptions.querySelector('input[type="radio"]:checked')?.value === "Page" ? 'FILL_ADVENT' : 'FILL_ADDATES'
    },
    tournament : { 
      api: () => `${API_TOURNAMENT}?url=${encodeURIComponent(inputValue)}`, 
      message: () => {
        const selected = tournamentOptions.querySelector('input[type="radio"]:checked').value;
        if (selected === 'Games ID') return 'FILL_GAMESID';
        if (selected === 'Currencies') return 'FILL_CURRENCIES';
        return 'FILL_TOURNAMENT';
      }
    },
    pretty: { 
      api: () => getActiveTabUrl().then(url => {
        const prettyType = document.querySelector('#prettyOp input[type="radio"]:checked')?.value === 'Casino Template' ? 'casino' : 
                                                                                                      'Variables' ? 'variables' : 'sport';
        return inputValue ? `${API_PRETTY}?url=${encodeURIComponent(url)}&type=${encodeURIComponent(prettyType)}&currencies=${inputValue}}`
                                : `${API_PRETTY}?url=${encodeURIComponent(url)}&type=${encodeURIComponent(prettyType)}}`;
      }),
      message: 'SHOW_ALERT'
    }
  };

  const cfg = CONFIG[type];

  try {
    let res;
    let data;
    let payload;
    const isNotPage = type === 'tournament' && ['Games ID', 'Currencies'].includes(tournamentOptions.querySelector('input[type="radio"]:checked')?.value) ||
                      type === 'advent' && adventOptions.querySelector('input[type="radio"]:checked')?.value === 'Dates';

    if (!isNotPage) {
      const apiUrl = await cfg.api();
      if (apiUrl) res = await fetch(apiUrl);
      else res = await fetch(cfg.api());

      data = await res.json();

      if (data.error) {
        console.error(data.error);
        return;
      }

      payload = data;
    } 
    if (isNotPage && type === 'tournament') {
      payload = { inputValue, points: pointsInput.value };
    }
    if (isNotPage && type === 'advent') {
      const startDate = document.getElementById('startDate')?.value;
      const endDate = document.getElementById('endDate')?.value;
      const daysCount = Number(document.getElementById('daysCount')?.value) || 1;
      payload = { startDate, endDate, daysCount };
    }
    if (type === 'pretty') {
      payload = {
        ...data,
        colors: {
          bg: getComputedStyle(document.documentElement).getPropertyValue('--main-btn').trim(),
          txt: getComputedStyle(document.documentElement).getPropertyValue('--btn-txt').trim()
        }
      };
    }

    if (cfg.message) {
      const messageType =
        typeof cfg.message === 'function' ? cfg.message() : cfg.message;

      chrome.tabs.query({ active: true, currentWindow: true }, ([tab]) => {
        if (!tab) return;
        chrome.tabs.sendMessage(tab.id, { type: messageType, payload });
      });
    }
    if (isNotPage && type === 'advent') {
      window.close();
    }

  } catch (err) {
    console.error(err);
  }
});

// === Update Check ====

initUpdateCheck();

async function initUpdateCheck() {
  try {
    const r = await fetch(VERSION_URL, { cache: "no-store" });
    if (!r.ok) return;
    const data = await r.json();
    const latest = data.version;
    const download = data.download;
    const updates = data.updates.map(u => `<span>${u}</span>`).join('<br>');
    if (!latest) return;

    const box = document.getElementById("updateBox");

    if (latest !== CURRENT_VERSION) {
      box.style.display = "block";
      box.innerHTML = `
        <div style="
          display: flex;
          flex-direction: column;
          justify-content: center;
          background: var(--body-bg);
          color: var(--p-txt);
          padding: 8px 12px;
          border-radius: 6px;
          font-size: 12px;
          border: 1px solid var(--brd);
          width: 100%;
          box-sizing: border-box;">

          <span style="display: block; text-align: center;">Better than before. Version ${latest} is here</span>
          <br>
          ${updates}
          
          <button id="downloadUpdate" class="toggle-btn" style="
            background: var(--input-field);
            color: var(--input-txt);
            border-radius: 6px;
            padding: 4px 8px;
            cursor: pointer;
            border: 1px solid var(--brd);
            font-size: 12px;
            white-space: nowrap;
            flex: 0 0 auto;
            width: auto;
            align-self: center;">Get it now</button>
        </div>
      `;

      document.getElementById("downloadUpdate").onclick = () => {
        chrome.tabs.create({ url: download });
      };
      return;
    }

    box.style.display = "none";
    box.innerHTML = '';
    checkReloadNeeded(box);

  } catch (e) {
    console.log("update check fail", e);
  }
}

// === Reload Check ===
function checkReloadNeeded(box) {
  chrome.tabs.query({ active: true, currentWindow: true }, ([tab]) => {
    chrome.tabs.sendMessage(tab.id, { type: "PING_EXTENSION" }, (res) => {
      if (chrome.runtime.lastError || !res) {
        box.style.display = "block";
        box.innerHTML = `
          <div style="
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            gap: 6px;
            background: var(--input-field);
            color: var(#e5e7eb);
            padding: 8px 12px;
            border-radius: 6px;
            font-size: 12px;
            border: 1px solid var(--brd);
            width: 100%;
            box-sizing: border-box;
          ">
            <span style="
              opacity: 0;
              animation: fadeBlink 3.5s ease-in-out infinite;
            ">
              It’s not broken. Just refresh the page.
            </span>
          </div>

          <style>
            @keyframes fadeBlink {
              0%   { opacity: 0.3; }
              50%  { opacity: 1; }
              100% { opacity: 0.3; }
            }
          </style>
        `;
      }
    });
  });
}

// === Theme ===
if (isCOM) {
  document.querySelector('[data-theme="pinup"]').style.display = 'flex';
} else if (isWL) {
  document.querySelector('[data-theme="pinco"]').style.display = 'flex';
}

const themeCurrent = document.getElementById('themeCurrent');
const themeDropdown = document.getElementById('themeDropdown');

themeCurrent.addEventListener('click', () => {
  themeDropdown.style.display =
    themeDropdown.style.display === 'block' ? 'none' : 'block';
});

function applyTheme(theme) {
  const root = document.documentElement;

  for (const sheet of document.styleSheets) {
    for (const rule of sheet.cssRules) {
      if (!rule.selectorText) continue;
      if (rule.selectorText === `[data-theme="${theme}"]`) {
        const cssText = rule.style.cssText;
        cssText.split(';').forEach(decl => {
          if (!decl) return;
          const [prop, value] = decl.split(':').map(s => s.trim());
          if (!prop || !value) return;
          const baseName = prop.slice(0, prop.lastIndexOf(`-${theme}`));
          root.style.setProperty(baseName, value);
        });
      }
    }
  }
}

document.querySelectorAll('.theme-option').forEach(opt => {
  opt.addEventListener('click', () => {
    const theme = opt.dataset.theme;
    applyTheme(theme);
    localStorage.setItem('cw_theme', theme);

    themeCurrent.textContent = opt.textContent + ' ▽';
    themeDropdown.style.display = 'none';
  });
});

(function initTheme() {
  let saved = localStorage.getItem('cw_theme');
  if (saved === "pinco" && isCOM) saved = "pinup";
  if (saved === "pinup" && isWL) saved = "pinco";
  if (!saved || !document.querySelector(`[data-theme="${saved}"]`)) {
    saved = 'dark-blue';
  }

  applyTheme(saved);

  const active = document.querySelector(`.theme-option[data-theme="${saved}"]`);
  if (active) {
    themeCurrent.textContent = active.textContent + ' ▽';
  }
})();

// === MANUAL + BUG LISTENER ===
document.addEventListener('click', (e) => {
  const button = e.target.closest('[data-link]');
  if (!button) return;
  window.open(button.dataset.link, '_blank');
});

}
