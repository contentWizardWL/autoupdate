// === DOMAIN CHECK ===
const domain = window.location.hostname;
const isWL = domain.includes('pincowin');
const isCOM = domain.includes('tech-pu') || domain.includes('spacer-way');

// === HELPER FUNCTIONS ===
function dispatchInputs(el, type='input') {
  el.dispatchEvent(new Event(type, { bubbles: true }));
}

function tinyMceFiller(data, indx = 0) {
  const iframes = document.querySelectorAll('.tox-edit-area__iframe');
  const text = (data || []).join('');
  const isEmpty = (doc) => {
    if (!doc || !doc.body) return true;
    return doc.body.innerText.replace(/\u00A0/g, '').trim().length === 0;
  };

  while (iframes[indx]) {
    const doc = iframes[indx].contentDocument || iframes[indx].contentWindow?.document;
    if (isEmpty(doc)) {
      doc.body.innerHTML = text;
      dispatchInputs(doc.body);
      break;
    }
    indx += 2;
  }
}

function fillFirstEmptyInput (selector, value) {
  const inputs = Array.from(document.querySelectorAll(selector));
  const emptyInput = inputs.find(input => !input.value);
  if (emptyInput) {
    emptyInput.value = value;
    emptyInput.dispatchEvent(new Event('input', { bubbles: true }));
  }
};

function clearEmptyInputs (selector) {
  const inputs = Array.from(document.querySelectorAll(selector));
  for (i = 0; i < inputs.length; i++) {
    const input = inputs[i]
    if (!input.value.trim()) input.value = '';
  }
}

function sleep(ms) {
  return new Promise(r => setTimeout(r, ms));
}

function waitForRender(selector, inputLength = 2, panel = document) {
  return new Promise(resolve => {
    const check = () => {
      const inputs = Array.from(panel.querySelectorAll(selector));
      if (inputs.length > inputLength) resolve(inputs);
      else setTimeout(check, 100);
    };
    check();
  });
}

async function fillTableData({ data, tableIndex, inputSelector, }) {
  if (!data?.length) return;

  const tables = document.querySelectorAll('table');
  const tbody = tables[tableIndex].querySelector('tbody');
  if (!tbody) return;

  const trs = Array.from(tbody.querySelectorAll('tr'));

  for (let i = 0; i < data.length; i++) {
    const tr = trs[i * 2];
    if (!tr) continue;

    tr.click();

    let input = null;

    for (let j = 0; j < 20; j++) {
      const inputs = Array.from(document.querySelectorAll(inputSelector));
      input = inputs.find(inp => !inp.value);
      if (input) break;
      await sleep(50);
    }

    if (input) {
      input.value = data[i];
      input.dispatchEvent(new Event('input', { bubbles: true }));
      await sleep(100);
    }
  }
}

// === PROMO ===
async function fillPromo(promo) {
  // === title, sd, fd, button ===
  const promoFields = {
    title: promo.title,
    shortDescription: promo.sd,
    buttonText: promo.button,
  };
    
  Object.entries(promoFields).forEach(([name, value]) => {
    if (!value) return;
    fillFirstEmptyInput(`[formcontrolname="${name}"]`, value);
  });

  tinyMceFiller(promo.fulld);

  // === text for user ===
  await fillTableData({
    data: promo.textForUser,
    tableIndex: 1,
    inputSelector: '[formcontrolname="textForUser"]',
  });

  // === steps ===
  await fillTableData({
    data: promo.steps,
    tableIndex: 2,
    inputSelector: '[formcontrolname="text"]',
  });
}

// === ADVENT ===
async function fillAdvent(data) {
  // === base ===
  const base = data[0];
    
  const baseFields = {
    title: base.title,
    subtitle: base.subTitle,
    buttonTextWhenUnopened: base.buttonU,
    buttonTextWhenOpened: base.buttonO,
  };
    
  Object.entries(baseFields).forEach(([name, value]) => {
    if (!value) return;
    fillFirstEmptyInput(`[formcontrolname="${name}"]`, value);
  });

  const tables = document.querySelectorAll('table');
  if (tables.length < 2) return;

  const tbody = tables[1].querySelector('tbody');
  if (!tbody) return;

  const trs = Array.from(tbody.querySelectorAll('tr'));

  // === days ===
  for (let i = 0; i < data.length - 1; i++) {
    const day = data[i + 1];
    const tr = trs[i * 2];

    if (!tr) continue;
    tr.click();

    const daysFields = {
      dayTitle: day.title,
      popupTitle: day.popupTitle,
      giftTitle: day.giftTitle,
      giftShortDescription: day.prizeShortDescription,
      giftLongDescription: day.prizeLongDescription?.trim(),
      popupButton: day.popupButton,
      //variableAmount: day.variable,
    };

    Object.entries(daysFields).forEach(([name, value]) => {
      fillFirstEmptyInput(`[formcontrolname="${name}"]`, value);
    });

    
    await sleep(100);
  }

  //clearEmptyInputs(`[formcontrolname="variableAmount"]`);
}

// === ADVENT DATES ===
async function datesFiller({ input, target, compareDate, fistDayIndex, incrementWhenEqual = false }) {
  input.focus();
  ['pointerdown', 'mousedown', 'mouseup', 'click'].forEach(type => {
    input.dispatchEvent(new MouseEvent(type, {
      bubbles: true,
      cancelable: true,
      view: window
    }));
  });

  await sleep(50);
  let btn = document.querySelector(`button[aria-label="${target.date}"]`);
  if (!btn) {
    document.querySelector(`button[aria-label="Next month"]`).click();
    await sleep(50);
    const btns = document.querySelectorAll('button[aria-label]');
    btn = btns[fistDayIndex];
    if (incrementWhenEqual ? target.date === compareDate : target.date !== compareDate) fistDayIndex++;
  }
  btn.click();

  await sleep(50);
  let matOptions = Array.from(document.querySelectorAll('mat-option'));
  matOptions[Number(target.hours)].click();
  await sleep(50);
  matOptions[24 + Number(target.minutes)].click();
  document.querySelector('div.action-panel button.mat-mdc-unelevated-button').click();
  return fistDayIndex;
}

async function fillAdDays(data) {
  const {startDate, endDate, daysCount } = data;
  const timeLine = buildTimeline(startDate, endDate, daysCount);
  const addBtn = document.querySelector('button.manage-entity__add-entity-button');
  console.log(timeLine);
  for (i = 3; i < timeLine.length / 2; i++) {
    addBtn.click()
  }
  await sleep(50);
  let fistDayIndex = 3;

  for (i = 0; i < timeLine.length / 2; i++) {
    const trs = document.querySelectorAll('tbody tr');
    const tr = trs[i * 2];
    tr.click();
    
    await sleep(50);
    const startInputs = document.querySelectorAll('input[formcontrolname="startDate"');
    const endInputs = document.querySelectorAll('input[formcontrolname="endDate"');
    
    fistDayIndex = await datesFiller({
      input: startInputs[i],
      target: timeLine[i * 2],
      compareDate: timeLine[i * 2 + 1].date,
      fistDayIndex,
      incrementWhenEqual: false
    });

    fistDayIndex = await datesFiller({
      input: endInputs[i],
      target: timeLine[i * 2 + 1],
      compareDate: timeLine[i * 2].date,
      fistDayIndex,
      incrementWhenEqual: true
    });
  }
}

function buildTimeline(start, end, stepDays = 1) {
  const s = new Date(start);
  const e = new Date(end);

  const result = [];
  const startType = 'startDate';
  const endType = 'endDate';

  const formatDate = (d) => `${d.toLocaleString("en-US", { month: "short" })} ${d.getDate()}, ${d.getFullYear()}`;

  const startM = s.getHours() * 60 + s.getMinutes();
  const endM = e.getHours() * 60 + e.getMinutes();
  const crossesMidnight = endM <= startM;

  let cursor = new Date(s);
  while (cursor <= e) {
    const startDate = new Date(cursor);
    const endDate = new Date(cursor);
    if (crossesMidnight) {
      endDate.setDate(endDate.getDate() + 1);
    }
    if (startDate > e) break;
    if (endDate > e) endDate.setTime(e.getTime());

    result.push({
      date: formatDate(startDate),
      hours: s.getHours(),
      minutes: s.getMinutes(),
      type: startType
    });

    result.push({
      date: formatDate(endDate),
      hours: e.getHours(),
      minutes: e.getMinutes(),
      type: endType
    });
    cursor.setDate(cursor.getDate() + stepDays);
  }
  return result;
}

// === TOURNAMENT PAGE ===
async function fillTournament(data) {
  fillFirstEmptyInput('[formcontrolname="title"]', data.title);
  fillFirstEmptyInput('[formcontrolname="participationButtonName"]', data.button);
  tinyMceFiller(data.shortDescription, 0);
  tinyMceFiller(data.shortRules, 1)
}

// === TOURNAMENT GAMES ID ===
function fillGamesId (data) {
  const input = document.querySelector('.mat-mdc-chip-input');
  const text = extractIds(data.inputValue).join(' ');
  input.focus();
  const clipboardData = new DataTransfer();
  clipboardData.setData('text/plain', text);

  input.dispatchEvent(new ClipboardEvent('paste', {
    clipboardData,
    bubbles: true
  }));

  input.dispatchEvent(new Event('input', { bubbles: true }));
}

function extractIds(text) {
  return text.match(/\t\s*\d+(?=\s|$)/g)?.map(x => x.trim()) ?? [];
}

// === TOURNAMENT BETS & POINTS ===
async function fillCurrencies (data) {
  const currencies = parseVariables(data.inputValue);
  const points = data.points.replace(/\D/g, '') || '1';
  const activePanel = document.querySelector('.side-panel.is-open')

  for (let i = 0; i < currencies.length - 1; i++) {
    activePanel.querySelector('.actions button').click();
  }
  
  const isBet = activePanel.querySelector('.side-panel__title').textContent.trim().includes('Min Bet');  
  const currencyDivs = await waitForRender('.mat-mdc-select-value', currencies.length - 1, activePanel);
  const placeholder = isBet ? 'Set Amount' : 'Real';

  for (let i = 0; i < currencies.length; i++) {
    currencyDivs[i].click();
    const inputs = await waitForRender('input.bo-select-search-input', 0);
    const input = inputs[0];
    input.value = currencies[i].code;
    input.dispatchEvent(new Event('input', { bubbles: true }));
    await sleep(30);
    const matOption = [...document.querySelectorAll('mat-option')].find(el => el.textContent.trim() === currencies[i].code);
    matOption.click();
      
    const amountInputs = activePanel.querySelectorAll(`input[placeholder="${placeholder}"]`);
    const amountInput = amountInputs[i];
    amountInput.value = currencies[i].formattedNumber.replace(',', '.').replace(/\s+/g, '');
    amountInput.dispatchEvent(new Event('input', { bubbles: true }));

    if (!isBet) {
      const pointsInputs = activePanel.querySelectorAll('input[placeholder="Points"]');
      const pointsInput = pointsInputs[i];
      pointsInput.value = points;
      pointsInput.dispatchEvent(new Event('input', { bubbles: true }));
    }
  }
}

// === TOURNAMENT POINTS CHECK ===
chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (msg.action === 'checkPointsInput') {
    const exists = !!document.querySelector('.side-panel.is-open')?.querySelector('input[placeholder="Points"]');
    sendResponse({ exists });
  }
});

// === VARIABLES ===
const CURRENCIES_MAP = { USD: "$", EUR: "€", TRY: "₺", RUB: "₽", KZT: "₸", AZN: "₼", KGS: "⊆", UZS: "SO'M", CAD: "C$", TJS: "SM", CDF: "FC", KES: "KSH",
                         NGN: "₦", GYD: "$", NIO: "C$", CRC: "₡", BOB: "Bs", HNL: "L", MXN: "$", CLP: "$", BDT: "BDT", INR: "INR", GTQ: "Q", };
const CURRENCIES_WL = ["EUR", "USD", "RUB", "TRY", "KZT", "AZN", "UZS", "CAD", "KGS", "TJS"];
const CURRENCIES_COM = ["EUR", "USD", "RUB", "UAH", "TRY", "KZT", "BRL", "ARS", "COP", "IDR", "AZN", "BGN", "UZS", "PLN", "INR", "PEN", 
                        "BYN", "CLP", "CAD", "MXN", "UYU", "BDT", "GTQ", "BOB", "HNL", "NGN", "KES", "CRC", "NIO", "CYD", "CDF"];
const PREFIX_CURRENCIES = ["USD", "EUR", "TRY", "CAD", "CLP", "MXN", "GTQ", "HNL", "BOB", "CRC", "NIO", "GYD", "NGN", "KES",];

const CURRENCIES = isCOM ? CURRENCIES_COM : CURRENCIES_WL;

function fillVariables(str) {
  const parsed = parseVariables(str);
  parsed.forEach(({ code, formattedNumber }) => {
    const value = formatCurrency(code, formattedNumber);
    const index = CURRENCIES.indexOf(code);
    if (index !== -1) {
      const input = document.getElementById(`sum${index}`);
      if (input) {
        input.value = value;
        input.dispatchEvent(new Event("input", { bubbles: true }));
      }
    }
  });
}

function parseVariables(str) {
  if (isCOM) str = str.replace('KSH', 'KES').replace(/(?<![A-Z])(CF|FC)(?![A-Z])/gi, 'CDF');
  const normalized = str.replace(/\\/g, "/");
  return normalized.split("/").map(s => s.trim()).filter(Boolean).map(part => {
      const codeMatch = part.match(new RegExp(CURRENCIES.join('|'), 'i'));
      if (!codeMatch) return null;

      const numberMatch = part.match(/[\d\s.,]+/);
      if (!numberMatch) return null;

      const code = codeMatch[0];
      const rawNumber = normalizeNumber(numberMatch[0]);
      const formattedNumber = formatNumber(rawNumber);

      return { code, formattedNumber };
    }).filter(Boolean);
}

function normalizeNumber(raw) {
  let str = raw.replace(/\s+/g, '');
  str = str.replace(/([.,])(\d+)/g, (_, sep, digits) => {
    if (digits.length <= 2) {
      return '.' + digits;
    }
    return digits;
  });
  str = str.replace(/,/g, '');
  return str;
}

function formatNumber(numStr) {
  const num = Number(numStr);
  if (Number.isNaN(num)) return numStr;

  return num.toLocaleString("ru-RU", {
      maximumFractionDigits: 10
    })
    .replace(/\u00A0/g, " ");
}

function formatCurrency(code, formattedNumber) {
  const symbol = CURRENCIES_MAP[code] || code;

  if (PREFIX_CURRENCIES.includes(code)) {
    return `${symbol} ${formattedNumber}`;
  }
  return `${formattedNumber} ${symbol}`;
}

// === SLOT / TEXT ===
async function fillLink(data) {
  const { url, currencies: fields } = data;
  const selectedFields = fields && fields.length ? fields : CURRENCIES;

  CURRENCIES.forEach((currency, index) => {
    const input = document.getElementById(`sum${index}`);
    if (!input) return;

    input.value = selectedFields.includes(currency) ? formatLink(url) : "";
    input.dispatchEvent(new Event('input', { bubbles: true }));
  });
}

function formatLink(str) {
  const match = str.match(/^(.*?)\((.*)\)$/); 
  if ((!match) || !(match[2].startsWith('/casino'))) return str;
  let name = match[1].trim();
  if (name.endsWith('-')) name = name.slice(0, name.length - 1).trim();
  const url = match[2].trim();
  return `<a target="_blank" href="${url}">${name}</a>`;
}

// === STEPS IMAGES ===
async function fillStepsImages(stepNumber) {
  const steps = Number(stepNumber);
  if (!steps || steps < 3 || steps > 5) return;
  let uploadedFiles = 2;

  for (let step = 1; step <= steps; step++) {
    const trIndex = (step - 1) * 2;
    const freshRows = Array.from(document.querySelectorAll('table tbody tr'));
    const tr = freshRows[trIndex];
    tr.click();

    let inputs = await waitForRender('input[type="file"]');

    let input1 = inputs[uploadedFiles];
    if (!input1) {
      input1 = inputs[inputs.length - 2]
    }
    const comSelector = isCOM ? 'com' : '';

    await setFile(input1, `steps_images/step${step + comSelector}.png`, `step${step + comSelector}`);

    inputs = await waitForRender('input[type="file"]');
    let input2 = inputs[uploadedFiles];

    if (!input2) {
      input2 = inputs[inputs.length - 1];
    }

    await setFile(input2, `steps_images/step${step + comSelector}.webp`, `step${step + comSelector}`);

    uploadedFiles += 2;
    await sleep(600);
    
  }
}

async function setFile(input, path, stepName) {
  const url = chrome.runtime.getURL(path);
  const res = await fetch(url);
  const blob = await res.blob();
  const file = new File([blob], path.split('/').pop(), { type: blob.type });
  const dt = new DataTransfer();
  dt.items.add(file);
  input.files = dt.files;

  input.dispatchEvent(new Event('change', { bubbles: true }));

  const regex = new RegExp(`^${stepName}_[a-zA-Z0-9]{4}\\.(png|webp)$`);

  await new Promise(resolve => {
    const observer = new MutationObserver((mutations, obs) => {
      const imgs = Array.from(document.querySelectorAll('img'));
      for (const img of imgs) {
        const filename = img.src.split('/').pop();
        if (regex.test(filename)) {
          obs.disconnect();
          resolve();
          break;
        }
      }
    });
    observer.observe(document.body, { childList: true, subtree: true });
  });
}

//=== SEGMENTS ===
const DEFAULT_EXCLUDED_SEGMENTS_WL_V1 = {
  'Excl Casino': '3135 WL_upd14.01_ExcludeTourn_Casino_CZ 3136 WL_upd14.01_ExcludeTourn_Casino_blocked 3138 WL_upd14.01_ExcludeTourn_Casino_RestrBonus',
  'Excl Sport': '3140 WL_upd14.01_ExcludeTourn_Sport_B2B3BZ 3142 WL_upd14.01_ExcludeTourn_Sport_blocked 3143 WL_upd14.01_ExcludeTourn_Sport_RestrBonus',
};
const DEFAULT_EXCLUDED_SEGMENTS_WL_V2 = {
  'Excl Casino': '1000532 WL_upd14.01_ExcludeTourn_Casino_CZ 1000533 WL_upd14.01_ExcludeTourn_blocked 1000534 WL_upd14.01_ExcludeTourn_Casino_RestrBonus',
  'Excl Sport': '1000535 WL_upd14.01_ExcludeTourn_Sport_B2B3BZ 1000533 WL_upd14.01_ExcludeTourn_blocked 1000537 WL_upd14.01_ExcludeTourn_Sport_RestrBonus',
};

const DEFAULT_EXCLUDED_SEGMENTS_COM_V1 = {
  'Excl Casino':'38161 tournament_casino_bad_statuses_1401 38162 tournament_casino_restr_bonuses_1401 38163 tournament_exclude_blocked_1401',
  'Excl Sport': '38164 tournament_sport_bad_statuses_1401 38165 tournament_sport_restr_bonuses_1401 38163 tournament_exclude_blocked_1401',
  'Excl CORE': '79558 EUR_lastbet90days_all_geo',
  'Excl AZ': '70181 AZ_exclude_other_currency_upd 65388 AZ_casino_status_C2',
  'Excl KZ-UZ': '79616 UZ_exclude_other_currency 79609 KZ_exclude_other_currency_prt2 79608 KZ_exclude_other_currency_prt1',
  'Excl IN-BD': '79630 IN_BD_exclude_other_currency_upd',
  'Excl LATAM': '79631 LATAM_exclude_other_currency_upd',
}

const DEFAULT_EXCLUDED_SEGMENTS_COM_V2 = {
  'Excl Casino':'1000063 tournament_casino_bad_statuses_1401 1000064 tournament_casino_restr_bonuses_1401 1000065 tournament_exclude_blocked_1401',
  'Excl Sport': '1000066 tournament_sport_bad_statuses_1401 1000067 tournament_sport_restr_bonuses_1401 1000065 tournament_exclude_blocked_1401',
  'Excl CORE': '1000068 EUR_lastbet90days_all_geo',
  'Excl AZ': '1000069 AZ_exclude_other_currency_upd 1000070 AZ_casino_status_C2',
  'Excl KZ-UZ': '1000071 UZ_exclude_other_currency 1000072 KZ_exclude_other_currency_prt2 1000074 KZ_exclude_other_currency_prt1',
  'Excl IN-BD': '1000075 IN_BD_exclude_other_currency_upd',
  'Excl LATAM': '1000076 LATAM_exclude_other_currency_upd',
}


async function fillSegments(data) {
  const isQuest = document.querySelector('body h4')?.textContent.includes('quest');
  let input = findInputByLabel("Excluded segments");

  const version = data.version;
  const TEST_SEGMENT_WL = version === 1 ? { sID: '3405', sName: 'UP_UP_popup_QAMAR_WL', } : { sID: '1000538', sName: 'UP_UP_popup_QAMAR_WL', };
  const TEST_SEGMENT_COM = version === 1 ? { sID: '39266', sName: 'UP_UP_popup_QAMAR_COM', } : { sID: '1000077', sName: 'UP_UP_popup_QAMAR_COM', };
  const DEFAULT_EXCLUDED_SEGMENTS_COM = version === 1 ? DEFAULT_EXCLUDED_SEGMENTS_COM_V1 : DEFAULT_EXCLUDED_SEGMENTS_COM_V2;
  const DEFAULT_EXCLUDED_SEGMENTS_WL = version === 1 ? DEFAULT_EXCLUDED_SEGMENTS_WL_V1 : DEFAULT_EXCLUDED_SEGMENTS_WL_V2;

  const DEFAULT_EXCLUDED_SEGMENTS = isCOM ? DEFAULT_EXCLUDED_SEGMENTS_COM : DEFAULT_EXCLUDED_SEGMENTS_WL
  
  const rawSegments = DEFAULT_EXCLUDED_SEGMENTS[data.type] ?? data.segments;
  
  const { segments, hasText } = formatSegments(rawSegments, isQuest);
  if (data.type === "Included") {
    input = findInputByLabel("Included segments");
    

    const testSegmentData = isCOM ? TEST_SEGMENT_COM : TEST_SEGMENT_WL;
    const { sID, sName } = testSegmentData;

    const testSegment = hasText ? (isQuest ? `${sName} ID ${sID}` : `${sID} ${sName}`) : sID;

    segments.push(testSegment);
  }

  let matCount = document.querySelectorAll('mat-chip-row').length + 1;

  for (let i = 0; i < segments.length; i++) {
    const presentSegments = Array.from(document.querySelectorAll('span.mdc-evolution-chip__text-label')).map(span => span.textContent.trim());
    if (presentSegments.includes(segments[i])) continue;
    
    input.value = segments[i];
    input.click();
    input.dispatchEvent(new Event('input', { bubbles: true }));

    await sleep(500);

    let option = null;

    if (hasText) {
      option = document.querySelector('.autocomplete-option__content, .mat-mdc-option-ripple');
    } else {
      option = checkSpanText(segments[i], isQuest);
    }
    if (!option) return alert(`Segment ${segments[i]} not found`);

    option.click();

    await new Promise(resolve => {
      const interval = setInterval(() => {
        const chipsCount = document.querySelectorAll('mat-chip-row').length;

        if (chipsCount === matCount) {
          clearInterval(interval);
          matCount++;
          resolve();
        }
      }, 100);
    });
  }
}

function findInputByLabel(labelText) {
  const labels = document.querySelectorAll('mat-label, label');

  for (const label of labels) {
    if (label.textContent.trim() !== labelText) continue;

    const walker = document.createTreeWalker(
      document.body,
      NodeFilter.SHOW_ELEMENT,
      null
    );

    walker.currentNode = label;

    let node;
    while ((node = walker.nextNode())) {
      if (node.tagName === 'INPUT') {
        return node;
      }
    }
  }

  return null;
}

function formatSegments(s, isQuest) {
  s = s.trim();

  if (/^[\d\s,\/]+$/.test(s)) {
    return {
      segments: s.split(/[\s,\/]+/).filter(Boolean),
      hasText: false,
    };
  }
  if (s.includes('\t')) s = s.replace(/\t\d+/g, '')

  const matches = s.match(/(\d+)\s*(\S+)/g) || [];

  return {
    segments: matches.map(seg => {
      const [, num, text] = seg.match(/(\d+)\s*(\S+)/);

      return isQuest ? `${text} ID ${num}` : `${num} ${text}`;
    }),
    hasText: true,
  };
}

function checkSpanText (num, isQuest) {
  const options = document.querySelectorAll('.autocomplete-option__content, .mat-ripple');
  for (let i = 0; i < options.length; i++) {
    const parentSpan = isQuest ? options[i].previousElementSibling : options[i].closest('span');
    if (!parentSpan) continue
    const text = parentSpan.textContent.trim();
    const match = isQuest ? text.match(/\d+$/) : text.match(/^\d+/);
    const optionNum = match ? match[0] : null;
    if (optionNum === num) return options[i];
  }
  return null;
}

// === LOCALES ===
const FULL_GEO = {
  'RU': 'Russia',
  'KZ': 'Kazakhstan',
  'AZ': 'Azerbaijan',
  'TR': 'Turkey',
  'KG': 'Kyrgyzstan',
  'UZ': 'Uzbekistan',
  'TJ': 'Tajikistan',
  'CA': 'Canada',
  'BD': 'Bangladesh',
  'BO': 'Bolivia',
  'CL': 'Chile',
  'CO': 'Colombia',
  'CD': 'Democratic Republic of the Congo',
  'GT': 'Guatemala',
  'HN': 'Honduras',
  'IN': 'India',
  'KE': 'Kenya',
  'MX': 'Mexico',
  'GY': 'Guyana',
  'NI': 'Nicaragua',
  'NG': 'Nigeria',
  'CR': 'Costa Rica',
  'EC': 'Ecuador',
};

async function fillLocales(data) {
  const h4 = document.querySelector('body h4')?.textContent?.trim();
  const isQuest = h4.includes('quest');
  const isChamp = h4.includes('championship');
  const locales = data.split(',').map(l => l.trim());
  const geo = isQuest ? 'GEO *' : isChamp ? 'Visible for specific geo' : 'GEO*';
  const input = findInputByLabel(geo);
  
  let matCount = document.querySelectorAll('mat-chip-row').length + 1;
  
  for (let i = 0; i < locales.length; i++) {
    isQuest || isChamp ? input.value = FULL_GEO[locales[i]] : input.value = locales[i];
    input.click();
    input.dispatchEvent(new Event('input', { bubbles: true }));

    await sleep(350);

    const option = document.querySelector('.autocomplete-option__content, .mat-mdc-option-ripple');

    if (!option) return

    option.click();

    await new Promise(resolve => {
      const interval = setInterval(() => {
        const chipsCount = document.querySelectorAll('mat-chip-row').length;

        if (chipsCount === matCount) {
          clearInterval(interval);
          matCount++;
          resolve();
        }
      }, 100);
    });
  }
  if (isQuest) input.click();
}


// === SLIDERS ===
const TOURNAMENT_TRANSLATIONS = {
  'ru': 'Турнир',
  'en': 'Tournament',
  'az': 'Turnir',
  'kk': 'Турнир',
  'ky': 'Турнир',
  'tg': 'Мусобиқа',
  'tr': 'Turnuva',
  'uz': 'Turnir',
  'es': 'Torneo',
  'hi': 'टूर्नामेंट',
  'bn': 'টুর্নামেন্ট',
  'pt': 'Torneio',
  'fr': 'Tournoi',
}

const RELEASE_TRANSLATIONS = {
  'ru': 'Релиз',
  'en': 'Release',
  'az': 'Reliz',
  'kk': 'Релиз',
  'ky': 'Релиз',
  'tg': 'Релиз',
  'tr': 'Yayımlandı',
  'uz': 'Relizi',
  'es': 'Lanzamiento',
  'hi': 'रिलीज',
  'bn': 'রিলিজ',
  'pt': 'Lançamento',
  'fr': 'Sortie',
}

const PRE_RELEASE_TRANSLATIONS = {
  'ru': 'Пре-релиз',
  'en': 'Pre-release',
  'az': 'Pre-reliz',
  'kk': 'Пре-релиз',
  'ky': 'Пре-релиз',
  'tg': 'Пре-релиз',
  'tr': 'Ön sürüm',
  'uz': 'Pre-relizi',
  'es': 'Pre-lanzamiento ',
  'hi': 'प्री-रिलीज़',
  'bn': 'প্রি-রিলিজ',
  'pt': 'Pré-lançamento',
  'fr': 'Pré-sortie',
}

const TRANSLATIONS = {
  'Tournament': TOURNAMENT_TRANSLATIONS,
  'Release': RELEASE_TRANSLATIONS,
  'Pre-Release': PRE_RELEASE_TRANSLATIONS,
}

function linkFiller(selector, link, option, marketOption) {
  const SLIDER_LANG_ORDER = [...document.querySelectorAll('lib-admin-toggle-buttons button')].map(btn => btn.getAttribute('title')?.slice(0, 2)).filter(Boolean);
  const blocks = document.querySelectorAll('map-language-banner-setting');
  blocks.forEach((block, idx) => {
    const titleInput = block.querySelector('#title');
    
    if (titleInput.value.trim()) {
      block.querySelector(selector).value = link;
      const subheader = block.querySelector('[formgroupname="subheader"]');
      const radios = subheader.querySelectorAll('input[type="radio"]')
      if (option === "Marketing Type") {
        radios[0].checked = true;
        const lang = SLIDER_LANG_ORDER[idx];
        const translations = TRANSLATIONS[marketOption]
        block.querySelector('#icon-text').value = translations[lang];
      } else {
        radios[2].checked = true;
      }
    }
  });
}

function fillSlider(data) {
  const { text, link, option, marketOption } = data;

  if (option === 'Text') fillSliderText(text);
  if (option === 'Link') {
    fillSliderLink(link, option, marketOption);
    const titles = [...document.querySelectorAll('#title')].filter(input => input.value);
    const descriptions = [...document.querySelectorAll('#description')].filter(input => input.value);
    const buttons = [...document.querySelectorAll('#button-text')].filter(input => input.value);
    const links = [...document.querySelectorAll('#button-link')].filter(input => input.value);
    const radios = [...document.querySelectorAll('input[type="radio"]:checked')];
    if (titles.length) titles.forEach(el => dispatchInputs(el));
    if (descriptions.length) descriptions.forEach(el => dispatchInputs(el));
    if (buttons.length) buttons.forEach(el => dispatchInputs(el));
    if (links.length) links.forEach(el => dispatchInputs(el));
    if (radios.length) radios.forEach(el => dispatchInputs(el, 'change'));
  }
  if (option === 'Marketing Type') {
    fillSliderLink(link, option, marketOption);
    const icons = [...document.querySelectorAll('#icon')].filter(input => input.value);
    const iconText = [...document.querySelectorAll('#icon-text')].filter(input => input.value);
    const radios = [...document.querySelectorAll('input[type="radio"]:checked')];
    if (icons.length) icons.forEach(el => dispatchInputs(el));
    if (iconText.length) iconText.forEach(el => dispatchInputs(el));
    if (radios.length) radios.forEach(el => dispatchInputs(el, 'change'));
  }
}

function fillSliderText(text) {
  const selectedArea = document.querySelector('.language-banner-setting_active');
  const clean = text.map(line => { 
    return line.replace(/^\s*1st line[^:]*:\s*/i, '')
               .replace(/^\s*2d line[^:]*:\s*/i, '')
               .replace(/^\s*3d line[^:]*:\s*/i, '')
               .replace(/^\s*button\s*:\s*/i, '')
               .replace(/^\(?(1st|2d|3d)\s*line\)?\s*/i, '')
    }).filter(Boolean);
  
  let titleText = clean[0];
  let descriptionText = clean.length === 3 ? clean[1] : `${clean[1]}<br>${clean[2]}`;
  const buttonText = clean.length === 3 ? clean[2] : clean[3];

  if (titleText.length > 19) {
    titleText = titleText.split(' ');
    const lastPart = titleText.pop();
    descriptionText = `${lastPart}<br>${descriptionText}`;
    titleText = titleText.join(' ');
  }
  selectedArea.querySelector('#title').value = titleText;
  selectedArea.querySelector('#description').value = descriptionText;
  selectedArea.querySelector('#button-text').value = buttonText;
}

function fillSliderLink(link, option, marketOption) {
  const inputId = option === "Link" ? "#button-link" : "#icon";
  linkFiller(inputId, link, option, marketOption);
}

// === PRETTY TOAST ===
function showToast(payload) {
  const text = payload.message;
  const div = document.createElement('div');
  div.textContent = text;

  const bgColor = payload.colors?.bg;
  const txtColor = payload.colors?.txt;
  Object.assign(div.style, {
    position: 'fixed',
    top: '250px',
    left: '50%',
    transform: 'translateX(-50%) translateY(-20px)',
    maxWidth: '400px',
    background: bgColor,
    color: txtColor,
    padding: '16px 24px',
    borderRadius: '10px',
    boxShadow: '0 4px 12px rgba(0,0,0,0.3)',
    fontSize: '14px',
    fontWeight: '500',
    zIndex: 9999,
    textAlign: 'center',
    opacity: 0,
    transition: 'opacity 0.3s ease, transform 0.3s ease'
  });

  document.body.appendChild(div);

  requestAnimationFrame(() => {
    div.style.opacity = 1;
    div.style.transform = 'translateX(-50%) translateY(0)';
  });

  setTimeout(() => {
    div.style.opacity = 0;
    div.style.transform = 'translateX(-50%) translateY(-20px)';
    div.addEventListener('transitionend', () => div.remove());
  }, 3000);
}

//=======================================================

const handlers = {
  FILL_PROMO: fillPromo,
  FILL_ADVENT: fillAdvent,
  FILL_LINK: fillLink,
  FILL_VARIABLES: fillVariables,
  FILL_STEPS: fillStepsImages,
  FILL_TOURNAMENT: fillTournament,
  FILL_SEGMENTS: fillSegments,
  FILL_LOCALES: fillLocales,
  FILL_GAMESID: fillGamesId,
  FILL_CURRENCIES: fillCurrencies,
  SHOW_ALERT: showToast,
  FILL_SLIDER: fillSlider,
  FILL_ADDATES: fillAdDays,
};

chrome.runtime.onMessage.addListener(({ type, payload }, _, sendResponse) => {
  if (type === "PING_EXTENSION") {
    sendResponse({ ok: true });
    return;
  }

  handlers[type]?.(payload);
});