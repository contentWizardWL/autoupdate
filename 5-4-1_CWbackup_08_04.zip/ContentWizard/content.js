const CURRENCIES_MAP = {
  USD: "$",
  EUR: "€",
  TRY: "₺",
  RUB: "₽",
  KZT: "₸",
  AZN: "₼",
  KGS: "⊆",
  UZS: "SO'M",
  CAD: "C$",
  TJS: "SM"
};

const CURRENCIES = ["EUR", "USD", "RUB", "TRY", "KZT", "AZN", "UZS", "CAD", "KGS", "TJS"];

const PREFIX_CURRENCIES = ["USD", "EUR", "TRY", "CAD"];

function tinyMceFiller(data, indx = 0) {
  const iframes = document.querySelectorAll('.tox-edit-area__iframe');
  const text = (data || []).join('');
  const isEmpty = (doc) => {
    if (!doc || !doc.body) return true;
    return doc.body.innerText.replace(/\u00A0/g, '').trim().length === 0;
  };

  while (iframes[indx]) {
    const doc = iframes[indx].contentDocument || iframes[indx].contentWindow?.document;
    if (isEmpty(doc)) {
      doc.body.innerHTML = text;
      doc.body.dispatchEvent(new Event('input', { bubbles: true }));
      break;
    }
    indx += 2;
  }
}

const fillFirstEmptyInput = (selector, value) => {
  const inputs = Array.from(document.querySelectorAll(selector));
  const emptyInput = inputs.find(input => !input.value.trim());
  if (emptyInput) {
    emptyInput.value = value || '';
    emptyInput.dispatchEvent(new Event('input', { bubbles: true }));
  }
};

function sleep(ms) {
  return new Promise(r => setTimeout(r, ms));
}

async function fillTableData({ data, tableIndex, inputSelector, }) {
  if (!data?.length) return;

  const tables = document.querySelectorAll('table');
  const tbody = tables[tableIndex].querySelector('tbody');
  if (!tbody) return;

  const trs = Array.from(tbody.querySelectorAll('tr'));

  for (let i = 0; i < data.length; i++) {
    const tr = trs[i * 2];
    if (!tr) continue;

    tr.click();

    let input = null;

    for (let j = 0; j < 20; j++) {
      const inputs = Array.from(document.querySelectorAll(inputSelector));
      input = inputs.find(inp => !inp.value.trim());
      if (input) break;
      await sleep(50);
    }

    if (input) {
      input.value = data[i];
      input.dispatchEvent(new Event('input', { bubbles: true }));
      await sleep(100);
    }
  }
}

// === PROMO ===
async function fillPromo(promo) {
  // === title, sd, fd, button ===
  const promoFields = {
    title: promo.title,
    shortDescription: promo.sd,
    buttonText: promo.button,
  };
    
  Object.entries(promoFields).forEach(([name, value]) => {
    if (!value) return;
    fillFirstEmptyInput(`[formcontrolname="${name}"]`, value);
  });

  tinyMceFiller(promo.fulld);

  // === text for user ===
  await fillTableData({
    data: promo.textForUser,
    tableIndex: 1,
    inputSelector: '[formcontrolname="textForUser"]',
  });

  // === steps ===
  await fillTableData({
    data: promo.steps,
    tableIndex: 2,
    inputSelector: '[formcontrolname="text"]',
  });
}

// === ADVENT ===
async function fillAdvent(data) {
  // === base ===
  const base = data[0];
    
  const baseFields = {
    title: base.title,
    subtitle: base.subTitle,
    buttonTextWhenUnopened: base.buttonU,
    buttonTextWhenOpened: base.buttonO,
  };
    
  Object.entries(baseFields).forEach(([name, value]) => {
    if (!value) return;
    fillFirstEmptyInput(`[formcontrolname="${name}"]`, value);
  });

  const tables = document.querySelectorAll('table');
  if (tables.length < 2) return;

  const tbody = tables[1].querySelector('tbody');
  if (!tbody) return;

  const trs = Array.from(tbody.querySelectorAll('tr'));

  // === days ===
  for (let i = 0; i < data.length - 1; i++) {
    const day = data[i + 1];
    const tr = trs[i * 2];

    if (!tr) continue;
    tr.click();

    const daysFields = {
      dayTitle: day.title,
      popupTitle: day.popupTitle,
      giftTitle: day.giftTitle,
      giftShortDescription: day.prizeShortDescription,
      giftLongDescription: day.prizeLongDescription?.trim(),
      popupButton: day.popupButton,
      variableAmount: day.variable,
    };

    Object.entries(daysFields).forEach(([name, value]) => {
      if (!value) return;
      fillFirstEmptyInput(`[formcontrolname="${name}"]`, value);
    });

    await sleep(100);
  }

}

// === TOURNAMENT ===
async function fillTournament(data) {
  fillFirstEmptyInput('[formcontrolname="title"]', data.title);
  fillFirstEmptyInput('[formcontrolname="participationButtonName"]', data.button);
  tinyMceFiller(data.shortDescription, 0);
  tinyMceFiller(data.shortRules, 1)
}

// === SLOT / TEXT ===
async function fillLink(data) {
  const { url, currencies: fields } = data;
  const selectedFields = fields && fields.length ? fields : CURRENCIES;

  CURRENCIES.forEach((currency, index) => {
    const input = document.getElementById(`sum${index}`);
    if (!input) return;

    input.value = selectedFields.includes(currency) ? formatLink(url) : "";
    input.dispatchEvent(new Event('input', { bubbles: true }));
  });
}

function formatLink(str) {
  const match = str.match(/^(.*?)\((.*)\)$/); 
  if ((!match) || !(match[2].startsWith('/casino'))) return str;
  let name = match[1].trim();
  if (name.endsWith('-')) name = name.slice(0, name.length - 1).trim();
  const url = match[2].trim();
  return `<a target="_blank" href="${url}">${name}</a>`;
}

// === VARIABLES ===
function fillVariables(str) {
  const parsed = parseVariables(str);
  parsed.forEach(({ code, formattedNumber }) => {
    const value = formatCurrency(code, formattedNumber);
    const index = CURRENCIES.indexOf(code);
    if (index !== -1) {
      const input = document.getElementById(`sum${index}`);
      if (input) {
        input.value = value;
        input.dispatchEvent(new Event("input", { bubbles: true }));
      }
    }
  });
}

function parseVariables(str) {
  const normalized = str.replace(/\\/g, "/");

  return normalized.split("/").map(s => s.trim()).filter(Boolean).map(part => {
      const codeMatch = part.match(/\b[A-Z]{3}\b/);
      if (!codeMatch) return null;

      const numberMatch = part.match(/[\d\s.,]+/);
      if (!numberMatch) return null;

      const code = codeMatch[0];
      const rawNumber = numberMatch[0].replace(/\s+/g, "").replace(",", ".");
      const formattedNumber = formatNumber(rawNumber);

      return { code, formattedNumber };
    }).filter(Boolean);
}

function formatNumber(numStr) {
  const num = Number(numStr);
  if (Number.isNaN(num)) return numStr;

  return num.toLocaleString("ru-RU", {
      maximumFractionDigits: 10
    })
    .replace(/\u00A0/g, " ");
}

function formatCurrency(code, formattedNumber) {
  const symbol = CURRENCIES_MAP[code] || code;

  if (PREFIX_CURRENCIES.includes(code)) {
    return `${symbol} ${formattedNumber}`;
  }
  return `${formattedNumber} ${symbol}`;
}

// === STEPS IMAGES ===
async function fillStepsImages(stepNumber) {
  const steps = Number(stepNumber);
  if (!steps || steps < 3 || steps > 5) return;
  let uploadedFiles = 2;

  for (let step = 1; step <= steps; step++) {
    const trIndex = (step - 1) * 2;
    const freshRows = Array.from(document.querySelectorAll('table tbody tr'));

    const tr = freshRows[trIndex];

    tr.click();
    console.log(`step ${step} clicked`);

    let inputs = await waitForInputs();

    let input1 = inputs[uploadedFiles];
    if (!input1) {
      input1 = inputs[inputs.length - 2]
    }

    await setFile(input1, `steps_images/step${step}.png`, `step${step}`);

    inputs = await waitForInputs();
    let input2 = inputs[uploadedFiles];

    if (!input2) {
      input2 = inputs[inputs.length - 1];
    }

    await setFile(input2, `steps_images/step${step}.webp`, `step${step}`);

    uploadedFiles += 2;
    await sleep(600);
    
  }
}

function waitForInputs() {
  return new Promise(resolve => {
    const check = () => {
      const inputs = Array.from(document.querySelectorAll('input[type="file"]'));
      if (inputs.length > 2) resolve(inputs);
      else setTimeout(check, 100);
    };
    check();
  });
}

async function setFile(input, path, stepName) {
  const url = chrome.runtime.getURL(path);
  const res = await fetch(url);
  const blob = await res.blob();
  const file = new File([blob], path.split('/').pop(), { type: blob.type });
  const dt = new DataTransfer();
  dt.items.add(file);
  input.files = dt.files;

  input.dispatchEvent(new Event('change', { bubbles: true }));

  const regex = new RegExp(`^${stepName}_[a-zA-Z0-9]{4}\\.(png|webp)$`);

  await new Promise(resolve => {
    const observer = new MutationObserver((mutations, obs) => {
      const imgs = Array.from(document.querySelectorAll('img'));
      console.log(imgs.length, imgs)
      for (const img of imgs) {
        const filename = img.src.split('/').pop();
        console.log(filename);
        if (regex.test(filename)) {
          obs.disconnect();
          resolve();
          break;
        }
      }
    });
    observer.observe(document.body, { childList: true, subtree: true });
  });
}

//=== SEGMENTS ===
async function fillSegments(data) {
  const isQuest = document.querySelector('body h4')?.textContent.trim() === 'Add quest';

  let input = findInputByLabel("Excluded segments");
  const { segments, hasText } = formatSegments(data.segments, isQuest);
  
  if (data.type === "Included") {
    input = findInputByLabel("Included segments");
    const testSegment = hasText? (isQuest ? 'UP_UP_popup_QAMAR_WL ID 3405' : '3405 UP_UP_popup_QAMAR_WL') : '3405';

    segments.push(testSegment);
  }

  let matCount = document.querySelectorAll('mat-chip-row').length + 1;

  for (let i = 0; i < segments.length; i++) {
    input.value = segments[i];
    input.click();
    input.dispatchEvent(new Event('input', { bubbles: true }));

    await sleep(500);

    let option = null;

    if (hasText) {
      option = document.querySelector('.autocomplete-option__content, .mat-mdc-option-ripple');
    } else {
      option = checkSpanText(segments[i], isQuest);
    }
    if (!option) return alert(`Segment ${segments[i]} not found`);

    option.click();

    await new Promise(resolve => {
      const interval = setInterval(() => {
        const chipsCount = document.querySelectorAll('mat-chip-row').length;

        if (chipsCount === matCount) {
          clearInterval(interval);
          matCount++;
          resolve();
        }
      }, 100);
    });
  }
}

function findInputByLabel(labelText) {
  const labels = document.querySelectorAll('mat-label, label');

  for (const label of labels) {
    if (label.textContent.trim() !== labelText) continue;

    const walker = document.createTreeWalker(
      document.body,
      NodeFilter.SHOW_ELEMENT,
      null
    );

    walker.currentNode = label;

    let node;
    while ((node = walker.nextNode())) {
      if (node.tagName === 'INPUT') {
        return node;
      }
    }
  }

  return null;
}

function formatSegments(s, isQuest) {
  s = s.trim();

  if (/^[\d\s,\/]+$/.test(s)) {
    return {
      segments: s.split(/[\s,\/]+/).filter(Boolean),
      hasText: false,
    };
  }

  const matches = s.match(/(\d+)\s*(\S+)/g) || [];

  return {
    segments: matches.map(seg => {
      const [, num, text] = seg.match(/(\d+)\s*(\S+)/);

      return isQuest ? `${text} ID ${num}` : `${num} ${text}`;
    }),
    hasText: true,
  };
}

function checkSpanText (num, isQuest) {
  const options = document.querySelectorAll('.autocomplete-option__content, .mat-ripple');
  for (let i = 0; i < options.length; i++) {
    const parentSpan = isQuest ? options[i].previousElementSibling : options[i].closest('span');
    if (!parentSpan) continue
    const text = parentSpan.textContent.trim();
    const match = isQuest ? text.match(/\d+$/) : text.match(/^\d+/);
    const optionNum = match ? match[0] : null;
    if (optionNum === num) return options[i];
  }
  return null;
}

// === Locales ===
const FULL_GEO = {
  'RU': 'Russia',
  'KZ': 'Kazakhstan',
  'AZ': 'Azerbaijan',
  'TR': 'Turkey',
  'KG': 'Kyrgyzstan',
  'UZ': 'Uzbekistan',
  'TJ': 'Tajikistan',
  'CA': 'Canada',
};

async function fillLocales(data) {
  const h4 = document.querySelector('body h4')?.textContent?.trim();
  const isQuest = h4.includes('quest');
  const isChamp = h4.includes('championship');
  const locales = data.split(',').map(l => l.trim());
  const geo = isQuest ? 'GEO *' : isChamp ? 'Visible for specific geo' : 'GEO*';
  const input = findInputByLabel(geo);
  
  let matCount = document.querySelectorAll('mat-chip-row').length + 1;
  
  for (let i = 0; i < locales.length; i++) {
    isQuest || isChamp ? input.value = FULL_GEO[locales[i]] : input.value = locales[i];
    input.click();
    input.dispatchEvent(new Event('input', { bubbles: true }));

    await sleep(500);

    const option = document.querySelector('.autocomplete-option__content, .mat-mdc-option-ripple');

    if (!option) return

    option.click();

    await new Promise(resolve => {
      const interval = setInterval(() => {
        const chipsCount = document.querySelectorAll('mat-chip-row').length;

        if (chipsCount === matCount) {
          clearInterval(interval);
          matCount++;
          resolve();
        }
      }, 100);
    });
  }
  if (isQuest) input.click();
}

// === Pretty Toast ===
function showToast(payload) {
  const text = payload.message;
  const div = document.createElement('div');
  div.textContent = text;

  const bgColor = payload.colors?.bg;
  const txtColor = payload.colors?.txt;
  Object.assign(div.style, {
    position: 'fixed',
    top: '250px',
    left: '50%',
    transform: 'translateX(-50%) translateY(-20px)',
    maxWidth: '400px',
    background: bgColor,
    color: txtColor,
    padding: '16px 24px',
    borderRadius: '10px',
    boxShadow: '0 4px 12px rgba(0,0,0,0.3)',
    fontSize: '14px',
    fontWeight: '500',
    zIndex: 9999,
    textAlign: 'center',
    opacity: 0,
    transition: 'opacity 0.3s ease, transform 0.3s ease'
  });

  document.body.appendChild(div);

  requestAnimationFrame(() => {
    div.style.opacity = 1;
    div.style.transform = 'translateX(-50%) translateY(0)';
  });

  setTimeout(() => {
    div.style.opacity = 0;
    div.style.transform = 'translateX(-50%) translateY(-20px)';
    div.addEventListener('transitionend', () => div.remove());
  }, 3000);
}

//=======================================================

const handlers = {
  FILL_PROMO: fillPromo,
  FILL_ADVENT: fillAdvent,
  FILL_LINK: fillLink,
  FILL_VARIABLES: fillVariables,
  FILL_STEPS: fillStepsImages,
  FILL_TOURNAMENT: fillTournament,
  FILL_SEGMENTS: fillSegments,
  FILL_LOCALES: fillLocales,
  SHOW_ALERT: showToast,
};

chrome.runtime.onMessage.addListener(({ type, payload }, _, sendResponse) => {
  if (type === "PING_EXTENSION") {
    sendResponse({ ok: true });
    return;
  }

  handlers[type]?.(payload);
});